# Why there's no .apk file here

This folder is where BUILD.md's commands put their output — it's checked
into the project (empty except this note) so the location is obvious.

No APK is included in this delivery because the environment this project
was assembled in has no Flutter SDK, no Android SDK, and no internet
access to fetch either — so `flutter build apk` could not actually be run
here. This is stated plainly rather than guessed around (see BUILD.md's
"Honesty note").

## How to get a real APK right now

**Option A — no setup, ~5 minutes:** push this project to a GitHub
repository. `.github/workflows/build_and_test.yml` runs automatically,
builds both a debug and a release APK for real on GitHub's own servers,
and attaches them to the workflow run under "Artifacts" — download them
from there.

**Option B — on your own machine, once Flutter/Android are installed
(see SETUP.md):**
```
flutter build apk --debug
```
produces `build/app/outputs/flutter-apk/app-debug.apk` — a real,
installable APK, not a placeholder. BUILD.md has the release and
App-Bundle commands too.
