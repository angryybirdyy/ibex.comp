# Architecture

## Layer diagram

```
ForexDataProvider (interface)
  ├─ DemoDataProvider        (deterministic synthetic candles, no key needed)
  └─ TwelveDataProvider      (live HTTP, rate-limited, retried)
        │
        ▼
MarketDataRepository          (data/market_data_repository.dart)
  — the only thing that talks to both a provider and the candle database.
  — handles offline detection, sync-state tracking, gap logging.
        │
        ▼
IndicatorEngine + 14 indicator classes   (indicators/)
        │
        ▼
Strategy (interface) × 24 implementations   (strategies/)
  — pure functions of the candles they're given; same class runs live
    and inside the backtester.
        │
        ▼
BacktestEngine                (backtesting/backtest_engine.dart)
  — causal bar-by-bar replay; the only source of a "win rate" anywhere
    in the app.
        │
        ▼
SignalEngine                  (signals/signal_engine.dart)
  — runs ALL 24 strategies every cycle, deduplicates, stores, resolves.
        │
        ▼
SignalDatabase (SQLite via sqflite)   (database/)
        │
        ▼
UI (screens/, widgets/, charts/, state/)
```

This mirrors the architecture the spec asked for. A few deliberate
deviations from the illustrative folder names, documented here rather than
silently renamed:

- "Repositories" (plural) became one `MarketDataRepository` under `data/`
  — there's only one thing to repository-ize (candles); signals and
  backtests are accessed directly through their DAOs since they don't need
  a provider-abstraction layer in front of them.
- "Notifications" and "background" became `services/notification_service.dart`
  and `services/background_service.dart` — both are small enough that a
  dedicated top-level folder each felt like unnecessary ceremony.
- `settings/` became `screens/settings/` (the UI) + `services/settings_repository.dart`
  (the persistence) + `state/settings_provider.dart` (the in-memory state) —
  split by what each piece actually does rather than kept as one folder.

## Key design decisions

**Strategies are pure functions of a candle window.** `Strategy.evaluate`
only ever looks at the `CandleSeries` it's handed — never anything else,
never mutable state carried between calls. This is what makes it safe for
`BacktestEngine` to call the exact same class, instance for instance, as
`SignalEngine` does live: a strategy genuinely cannot behave differently in
a backtest than it does in production, because it's the same code path.

**Chart visibility and signal generation are different systems, on
purpose.** `StrategySettingsDao.chart_enabled` is read by `ChartScreen`
only. `SignalEngine` iterates `StrategyRegistry.all` directly and never
even has a reference to `StrategySettingsDao`'s selection table. This
isn't just a convention — it's structurally impossible for a disabled
chart strategy to stop generating signals, because the two code paths
don't share that state at all (spec sections 9/44).

**Signal identity is the deduplication mechanism.**
`core/id_utils.dart#buildSignalIdentity` builds a deterministic id from
(pair, timeframe, strategy, candle timestamp, direction). `SignalDao.insertIfNew`
uses `INSERT OR IGNORE` on that id as the primary key. There's no separate
"has this already fired?" query — the database's own primary-key
constraint *is* the dedup logic, which also means it can never race (two
concurrent inserts for the same event can't both succeed).

**The backtester and live signal resolution share one TP/SL module.**
`backtesting/tpsl_rules.dart`'s `computeTpSl` and `evaluateSignalOutcome`
are called by both `BacktestEngine` and `signals/signal_resolver.dart`.
A signal's "did this win?" is answered identically whether it happened
during a backtest over last year's data or five minutes ago live.

**Indicators return full-length, index-aligned, nullable arrays.**
Every indicator in `indicators/` returns a `List<double?>` the same length
as the input candles, with `null` during warm-up. Strategies read the last
element; the chart reads the whole array for overlays. One computation,
two consumers, no drift between "what the strategy saw" and "what's drawn."

## Known limitations (disclosed, not hidden)

**Oscillator-style indicators show as a badge, not a sub-panel.** RSI,
MACD, Stochastic, Stochastic RSI, ADX, Mean Reversion's z-score, and ROC
don't live on the same numeric scale as price, so drawing them as a line
*on* the candlestick chart would be meaningless. Rather than build a second
stacked panel underneath the price chart — a real feature, but a
substantially bigger undertaking — v1 shows each of these as a compact
"RSI 28.4" style badge above the chart when that strategy is enabled (see
`strategies/strategy_overlays.dart`). The strategy's actual BUY/SELL
triggers still show as markers on the price chart either way. A stacked
oscillator panel is the natural v2 addition.

**Backtests cap at a bounded number of recent candles.** `BacktestEngine`
re-evaluates a strategy on a causally-growing window at every single
candle, which is what guarantees it never leaks future data into a
decision — the same reason it's safe to reuse live strategy code
unchanged. The cost of that honesty is roughly O(n²) in candle count for one
full backtest run. `BacktestEngine.defaultMaxCandles` (3,000, hard cap
6,000) keeps a single run's cost predictable regardless of timeframe — for
very fine timeframes (1M/5M) over a long requested period, this means the
most recent ~3,000 candles are analyzed rather than the entire range, and
the `BacktestResult.startDate`/`endDate` always reflect what was *actually*
analyzed, never the originally-requested range. See STRATEGIES.md.

**`IndicatorEngine`'s cache is a single shared, process-wide cache.**
A long backtest run and live chart rendering can evict each other's cached
entries, since both go through the same bounded cache. This only costs a
little recomputation, never correctness — each cache key embeds the exact
series length and last timestamp, so a stale hit is impossible — but a
future version could give the backtester its own throwaway cache instance
to avoid the cross-talk entirely.

**`flutter_foreground_task`'s exact `TaskHandler` method signatures are the
single most likely thing to drift** between when this was written and when
you run `flutter pub get`, since it's a fast-moving plugin. See
`services/background_service.dart`'s doc comment and TROUBLESHOOTING.md.

**Parabolic SAR is drawn as a connected line, not individual dots.** Most
charting platforms draw PSAR as discrete dots above/below price; this
chart's generic line-overlay renderer draws it as a thin continuous line
instead, which is visually a reasonable simplification but not pixel-identical
to convention.

**The Strategies screen's two info affordances are intentionally
different things.** The spec describes one "information button at the top"
that documents every strategy. This app provides that top button as a
general explainer (the ON/OFF-vs-signals distinction, and the win-rate
methodology) *and* a separate per-row (i) button for each strategy's full
spec-required detail page — interpreting "for every strategy, show [a long
list of fields]" as calling for one detail view per strategy rather than
one single page listing all 24 strategies' full detail in a row.
