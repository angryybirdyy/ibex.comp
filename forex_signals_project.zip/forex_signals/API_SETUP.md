# API Setup

The app works fully in **Demo mode** with no API key — every feature
(charts, strategies, signals, backtesting, notifications, background
monitoring) works against clearly-labelled synthetic data. This document
covers switching to **live** prices.

## Why Twelve Data

Chosen for this project because its free tier covers forex OHLC candles at
every interval this app needs (1min, 5min, 15min, 30min, 1h, 4h, 1day)
directly, with documented, predictable rate limits. **Check their current
plans and limits before relying on this** — API providers change terms
over time: <https://twelvedata.com/pricing> and <https://twelvedata.com/docs>.

## Getting a key

1. Go to <https://twelvedata.com> and create a free account.
2. Your API key is shown on your account dashboard immediately — no credit
   card needed for the free tier at the time of writing.

## Entering it in the app

**Settings → Data source → Live (Twelve Data) → paste your key → tap the
save icon.**

The key is stored using Android's encrypted secure storage
(`flutter_secure_storage`, backed by the Android Keystore) — never in
plain SharedPreferences, never in a log line, never in source control. See
`services/api_key_store.dart`.

## Rate limits — why the app paces itself

Twelve Data's free tier is credit-based per minute. This app's live
provider (`data/twelve_data_provider.dart`) enforces its own local rate
limiter (`data/rate_limiter.dart`, a token bucket) on top of whatever the
API itself enforces, and retries transient failures (timeouts, 5xx errors)
with backoff rather than hammering the endpoint. Two practical
consequences:

- The background monitoring cycle defaults to syncing only **15M, 1H, 4H,
  1D** (Settings → Background timeframes) rather than all 7, specifically
  to stay well inside a free-tier budget with two pairs. Add 1M/5M there if
  your plan supports the extra request volume.
- If you see "API rate limit reached," it's expected occasionally under a
  free plan with frequent refreshes — raise your refresh interval in
  Settings, or upgrade your Twelve Data plan.

## Switching to a different provider later

The entire app talks to data through one interface:
`data/forex_data_provider.dart`. To add provider #3:

1. Implement `ForexDataProvider` (two methods: `getCurrentPrice`,
   `getCandles`).
2. Add one case to `data/provider_factory.dart`.
3. Add it to the Settings screen's data-source picker.

Nothing in the indicator, strategy, backtesting, signal, or UI layers
needs to change — they only ever talk to `MarketDataRepository`, never to
a provider directly.

## Demo mode details

`data/demo_data_provider.dart` generates candles from a deterministic
function of wall-clock time (a couple of slow sine cycles plus
hash-seeded per-candle noise) rather than a stored random walk — so
querying the same time range twice always returns the same candles, which
is what makes a "backtest" on demo data a real, repeatable computation
rather than a different fake number each time. Every demo candle is
flagged `isDemo: true`, and the UI shows a "DEMO DATA" banner whenever
you're looking at it.
