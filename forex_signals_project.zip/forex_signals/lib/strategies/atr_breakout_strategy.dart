import '../core/enums.dart';
import '../indicators/atr.dart';
import '../indicators/indicator_engine.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #10 — ATR Breakout. A volatility-based breakout: a move bigger than a
/// multiple of the average true range signals a genuine break rather than
/// normal noise.
class AtrBreakoutStrategy extends Strategy {
  @override
  String get id => 'atr_breakout';

  @override
  int get minCandles => 40;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'ATR period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(
            key: 'multiple', label: 'ATR multiple', defaultValue: 1.5, min: 0.5, max: 4, step: 0.1, isInteger: false),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'ATR Breakout',
        shortExplanation:
            'Signals when a single candle moves further than normal volatility would suggest.',
        indicatorsUsed: const ['ATR (Average True Range)'],
        calculationLogic:
            'ATR measures typical candle range. A breakout is flagged when the close moves '
            'more than `multiple × ATR` away from the previous close in one candle.',
        buyConditions: 'Close rises more than `multiple × ATR` above the previous close.',
        sellConditions: 'Close falls more than `multiple × ATR` below the previous close.',
        neutralConditions: 'Move size stays within the normal ATR-based range.',
        suitableMarketConditions:
            'Markets breaking out of a quiet period, e.g. around news or session opens.',
        typicalWeaknesses:
            'A single volatile candle does not guarantee follow-through; ATR spikes are '
            'sometimes one-off and mean-revert immediately.',
        usualTimeframes: '15M, 1H, 4H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final multiple = params['multiple']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final atr = IndicatorEngine.memoize('$base|atr|$period', () => Atr.compute(series, period: period));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'Move size is within the normal ATR-based range.';

    if (i > 0 && atr[i - 1] != null) {
      final threshold = atr[i - 1]! * multiple;
      final change = last.close - series[i - 1].close;
      if (change > threshold) {
        direction = StrategyDirection.buy;
        reason = 'Close rose ${change.toStringAsFixed(5)}, more than $multiple× ATR '
            '(${threshold.toStringAsFixed(5)}).';
      } else if (change < -threshold) {
        direction = StrategyDirection.sell;
        reason = 'Close fell ${change.abs().toStringAsFixed(5)}, more than $multiple× ATR '
            '(${threshold.toStringAsFixed(5)}).';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {if (atr[i] != null) 'atr': atr[i]!},
      explanation: reason,
    );
  }
}
