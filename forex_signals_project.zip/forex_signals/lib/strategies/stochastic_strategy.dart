import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/stochastic.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #6 — Stochastic Oscillator. %K/%D cross, gated to the extreme zones so it
/// only fires on genuine reversal setups rather than every mid-range cross.
class StochasticStrategy extends Strategy {
  @override
  String get id => 'stochastic';

  @override
  int get minCandles => 40;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: '%K period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(key: 'k_smooth', label: '%K smoothing', defaultValue: 3, min: 1, max: 10),
        StrategyParamSpec(key: 'd_period', label: '%D period', defaultValue: 3, min: 1, max: 10),
        StrategyParamSpec(key: 'oversold', label: 'Oversold level', defaultValue: 20, min: 5, max: 30),
        StrategyParamSpec(key: 'overbought', label: 'Overbought level', defaultValue: 80, min: 70, max: 95),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Stochastic Oscillator',
        shortExplanation:
            'Compares the close to its recent high/low range to spot momentum turns near extremes.',
        indicatorsUsed: const ['Stochastic %K', 'Stochastic %D'],
        calculationLogic:
            '%K measures where the close sits within the recent high/low range; %D is a '
            'moving average of %K. Signals require the cross to happen inside the '
            'oversold/overbought zone.',
        buyConditions: '%K crosses above %D while below the oversold level.',
        sellConditions: '%K crosses below %D while above the overbought level.',
        neutralConditions: 'Cross happens outside the extreme zones, or no cross at all.',
        suitableMarketConditions: 'Range-bound markets oscillating between support/resistance.',
        typicalWeaknesses: 'Can stay pinned near an extreme through a strong trend, giving early '
            'or repeated counter-trend signals.',
        usualTimeframes: '15M, 1H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final kSmooth = params['k_smooth']!.toInt();
    final dPeriod = params['d_period']!.toInt();
    final oversold = params['oversold']!.toDouble();
    final overbought = params['overbought']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final stoch = IndicatorEngine.memoize(
      '$base|stoch|$period|$kSmooth|$dPeriod',
      () => Stochastic.compute(series, period: period, kSmoothing: kSmooth, dPeriod: dPeriod),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No %K/%D cross inside an extreme zone.';

    if (crossedAbove(stoch.percentK, stoch.percentD, i) &&
        (stoch.percentK[i] ?? 100) < oversold) {
      direction = StrategyDirection.buy;
      reason = '%K crossed above %D while below the oversold level ($oversold).';
    } else if (crossedBelow(stoch.percentK, stoch.percentD, i) &&
        (stoch.percentK[i] ?? 0) > overbought) {
      direction = StrategyDirection.sell;
      reason = '%K crossed below %D while above the overbought level ($overbought).';
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (stoch.percentK[i] != null) 'stoch_k': stoch.percentK[i]!,
        if (stoch.percentD[i] != null) 'stoch_d': stoch.percentD[i]!,
      },
      explanation: reason,
    );
  }
}
