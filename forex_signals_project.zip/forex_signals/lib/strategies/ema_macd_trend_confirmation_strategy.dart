import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/macd.dart';
import '../indicators/moving_averages.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #19 — EMA + MACD Trend Confirmation. Distinct from #17/#18: here the EMA
/// pair is a standing *trend filter* (is a trend already established?) and
/// the trigger event is the MACD histogram crossing zero — i.e. momentum
/// turning in the direction of the existing trend, rather than either line
/// crossing the other.
class EmaMacdTrendConfirmationStrategy extends Strategy {
  @override
  String get id => 'ema_macd_trend_confirmation';

  @override
  int get minCandles => 100;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'ema_fast', label: 'Trend filter EMA (fast)', defaultValue: 20, min: 5, max: 60),
        StrategyParamSpec(key: 'ema_slow', label: 'Trend filter EMA (slow)', defaultValue: 50, min: 20, max: 200),
        StrategyParamSpec(key: 'macd_fast', label: 'MACD fast EMA', defaultValue: 12, min: 3, max: 50),
        StrategyParamSpec(key: 'macd_slow', label: 'MACD slow EMA', defaultValue: 26, min: 10, max: 100),
        StrategyParamSpec(key: 'macd_signal', label: 'MACD signal EMA', defaultValue: 9, min: 3, max: 50),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'EMA + MACD Trend Confirmation',
        shortExplanation:
            'Uses EMA alignment as a standing trend filter and MACD histogram crossing zero '
            'as the entry trigger.',
        indicatorsUsed: const ['EMA (fast/slow trend filter)', 'MACD histogram'],
        calculationLogic:
            'An uptrend/downtrend is defined by fast EMA vs. slow EMA. Within that trend, an '
            'entry triggers when the MACD histogram crosses zero in the same direction.',
        buyConditions: 'Fast EMA is above slow EMA AND the MACD histogram crosses above zero.',
        sellConditions: 'Fast EMA is below slow EMA AND the MACD histogram crosses below zero.',
        neutralConditions: 'Histogram crosses zero against the EMA trend, or no cross at all.',
        suitableMarketConditions: 'Established trends with a temporary momentum pullback that '
            'is now resuming.',
        typicalWeaknesses:
            'Requires two lagging conditions to align, so entries can come well after the best '
            'part of a move.',
        usualTimeframes: '4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final emaFastP = params['ema_fast']!.toInt();
    final emaSlowP = params['ema_slow']!.toInt();
    final macdFast = params['macd_fast']!.toInt();
    final macdSlow = params['macd_slow']!.toInt();
    final macdSignal = params['macd_signal']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final emaFastSeries =
        IndicatorEngine.memoize('$base|ema|$emaFastP', () => Ema.compute(series, period: emaFastP));
    final emaSlowSeries =
        IndicatorEngine.memoize('$base|ema|$emaSlowP', () => Ema.compute(series, period: emaSlowP));
    final macd = IndicatorEngine.memoize(
      '$base|macd|$macdFast|$macdSlow|$macdSignal',
      () => Macd.compute(series, fast: macdFast, slow: macdSlow, signalPeriod: macdSignal),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No qualifying MACD histogram cross in the direction of the EMA trend.';

    final fastNow = emaFastSeries[i], slowNow = emaSlowSeries[i];
    final hist0 = i > 0 ? macd.histogram[i - 1] : null;
    final hist1 = macd.histogram[i];

    if (fastNow != null && slowNow != null && hist0 != null && hist1 != null) {
      final uptrend = fastNow > slowNow;
      if (uptrend && hist0 <= 0 && hist1 > 0) {
        direction = StrategyDirection.buy;
        reason = 'EMA trend is up and the MACD histogram just crossed above zero.';
      } else if (!uptrend && hist0 >= 0 && hist1 < 0) {
        direction = StrategyDirection.sell;
        reason = 'EMA trend is down and the MACD histogram just crossed below zero.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (emaFastSeries[i] != null) 'ema_fast': emaFastSeries[i]!,
        if (emaSlowSeries[i] != null) 'ema_slow': emaSlowSeries[i]!,
        if (macd.histogram[i] != null) 'macd_hist': macd.histogram[i]!,
      },
      explanation: reason,
    );
  }
}
