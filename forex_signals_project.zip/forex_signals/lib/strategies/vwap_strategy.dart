import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/vwap.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #16 — VWAP. Treats the session Volume Weighted Average Price as a fair-
/// value line; a close crossing it signals a shift in intraday sentiment.
class VwapStrategy extends Strategy {
  @override
  String get id => 'vwap';

  @override
  int get minCandles => 20;

  @override
  List<StrategyParamSpec> get paramSpecs => const [];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'VWAP',
        shortExplanation:
            'Compares price to the session\'s volume-weighted average price, a common '
            'intraday "fair value" reference.',
        indicatorsUsed: const ['VWAP (session-cumulative, resets daily UTC)'],
        calculationLogic:
            'VWAP = Σ(typical price × volume) ÷ Σ(volume), accumulated from the start of the '
            'UTC trading day. Forex volume from most providers is tick volume (an update '
            'count), not true traded volume — VWAP here should be read as tick-activity '
            'weighted, not a literal traded-volume average.',
        buyConditions: 'Close crosses above VWAP.',
        sellConditions: 'Close crosses below VWAP.',
        neutralConditions: 'No cross on the current candle.',
        suitableMarketConditions: 'Intraday sessions with a meaningful volume/activity profile.',
        typicalWeaknesses:
            'Resets each day, so it is less meaningful right after a session start, and forex '
            "volume being tick-based (not true traded volume) makes it a rougher gauge than "
            'on an exchange-traded instrument.',
        usualTimeframes: '1M, 5M, 15M',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final vwap = IndicatorEngine.memoize('$base|vwap', () => Vwap.compute(series));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No VWAP cross on this candle.';

    if (i > 0 && vwap[i - 1] != null && vwap[i] != null) {
      final close0 = series[i - 1].close, close1 = last.close;
      if (close0 <= vwap[i - 1]! && close1 > vwap[i]!) {
        direction = StrategyDirection.buy;
        reason = 'Price crossed above session VWAP.';
      } else if (close0 >= vwap[i - 1]! && close1 < vwap[i]!) {
        direction = StrategyDirection.sell;
        reason = 'Price crossed below session VWAP.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {if (vwap[i] != null) 'vwap': vwap[i]!},
      explanation: reason,
    );
  }
}
