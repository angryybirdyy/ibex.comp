import '../core/enums.dart';
import '../indicators/adx.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #13 — ADX + DI. Uses the directional lines' cross for direction, but
/// only trusts it when ADX confirms there's an actual trend to trade.
class AdxDiStrategy extends Strategy {
  @override
  String get id => 'adx_di';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'ADX/DI period', defaultValue: 14, min: 5, max: 40),
        StrategyParamSpec(
            key: 'adx_threshold', label: 'Min ADX (trend strength)', defaultValue: 20, min: 10, max: 40),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'ADX + DI',
        shortExplanation:
            'Uses +DI/-DI direction, but only when ADX confirms the trend is strong enough to trust.',
        indicatorsUsed: const ['+DI', '-DI', 'ADX'],
        calculationLogic:
            '+DI/-DI measure directional movement; ADX measures trend strength regardless of '
            'direction. A DI cross is only acted on when ADX is above the threshold.',
        buyConditions: '+DI crosses above -DI while ADX is above the threshold.',
        sellConditions: '-DI crosses above +DI while ADX is above the threshold.',
        neutralConditions: 'A DI cross happens but ADX is below the threshold (weak/no trend).',
        suitableMarketConditions: 'Established trending conditions, filtered away from chop.',
        typicalWeaknesses:
            'ADX is itself a lagging, smoothed indicator, so confirmation arrives after the '
            'trend has already started.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final threshold = params['adx_threshold']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final adx = IndicatorEngine.memoize('$base|adx|$period', () => Adx.compute(series, period: period));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No qualifying +DI/-DI cross.';

    final adxNow = adx.adx[i];
    if (adxNow != null && adxNow >= threshold) {
      if (crossedAbove(adx.plusDi, adx.minusDi, i)) {
        direction = StrategyDirection.buy;
        reason = '+DI crossed above -DI with ADX at ${adxNow.toStringAsFixed(1)} (≥ $threshold).';
      } else if (crossedBelow(adx.plusDi, adx.minusDi, i)) {
        direction = StrategyDirection.sell;
        reason = '-DI crossed above +DI with ADX at ${adxNow.toStringAsFixed(1)} (≥ $threshold).';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (adx.plusDi[i] != null) 'plus_di': adx.plusDi[i]!,
        if (adx.minusDi[i] != null) 'minus_di': adx.minusDi[i]!,
        if (adx.adx[i] != null) 'adx': adx.adx[i]!,
      },
      explanation: reason,
    );
  }
}
