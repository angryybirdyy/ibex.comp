import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #24 — Momentum Breakout. Rate-of-change based: distinct from ATR
/// Breakout (#10, single-candle volatility) and Donchian Breakout (#11,
/// price range) — this measures sustained percentage momentum over a
/// window of candles.
class MomentumBreakoutStrategy extends Strategy {
  @override
  String get id => 'momentum_breakout';

  @override
  int get minCandles => 40;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'ROC period', defaultValue: 10, min: 3, max: 40),
        StrategyParamSpec(
            key: 'threshold_pct', label: 'ROC threshold (%)', defaultValue: 0.5, min: 0.1, max: 5, step: 0.1, isInteger: false),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Momentum Breakout',
        shortExplanation:
            'Measures the percentage price change over a recent window to catch sustained '
            'momentum moves.',
        indicatorsUsed: const ['Rate of Change (ROC)'],
        calculationLogic:
            'ROC = (close − close [period bars ago]) ÷ close [period bars ago] × 100. A '
            'signal fires when ROC crosses the configured threshold.',
        buyConditions: 'ROC crosses above the positive threshold.',
        sellConditions: 'ROC crosses below the negative threshold.',
        neutralConditions: 'ROC stays within the threshold band.',
        suitableMarketConditions: 'Markets with a sudden, sustained directional push.',
        typicalWeaknesses:
            'Can fire late in a move (momentum has already been building for `period` candles '
            'by the time it triggers) and is sensitive to the threshold/period chosen.',
        usualTimeframes: '15M, 1H, 4H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final thresholdPct = params['threshold_pct']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final roc = IndicatorEngine.memoize('$base|roc|$period', () => rocSeries(series.closes, period));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'Momentum is within the normal threshold band.';

    if (i > 0 && roc[i - 1] != null && roc[i] != null) {
      final prev = roc[i - 1]!, cur = roc[i]!;
      if (prev <= thresholdPct && cur > thresholdPct) {
        direction = StrategyDirection.buy;
        reason = '${period}-candle ROC crossed above +$thresholdPct% '
            '(now ${cur.toStringAsFixed(2)}%).';
      } else if (prev >= -thresholdPct && cur < -thresholdPct) {
        direction = StrategyDirection.sell;
        reason = '${period}-candle ROC crossed below -$thresholdPct% '
            '(now ${cur.toStringAsFixed(2)}%).';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {if (roc[i] != null) 'roc': roc[i]!},
      explanation: reason,
    );
  }
}
