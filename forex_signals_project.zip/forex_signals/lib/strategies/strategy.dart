import '../core/enums.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';

/// The contract every strategy satisfies (spec section 42). A `Strategy` is
/// a pure function of the candles it's given: `evaluate` must only look at
/// data already inside [series] (never anything outside it), which is what
/// lets the exact same class be used both for live signal generation *and*
/// for causal, bar-by-bar backtest replay (`backtesting/backtest_engine.dart`
/// simply calls `evaluate` on a growing window and never lets a strategy see
/// a candle "from the future").
///
/// Adding strategy #25 means: write a class implementing this interface,
/// give it a [StrategyMeta] entry, and register it in
/// `strategy_registry.dart`. Nothing else in the app needs to change.
abstract class Strategy {
  /// Stable id, must match the corresponding [StrategyMeta.id].
  String get id;

  StrategyMeta get meta;

  /// Configurable numeric parameters this strategy exposes in Settings
  /// (spec section 23), each with sensible defaults.
  List<StrategyParamSpec> get paramSpecs;

  /// Minimum candle count this strategy needs before it can produce a
  /// meaningful (non-neutral) result. Enforced by [evaluateSafe].
  int get minCandles;

  /// Evaluates the *last* candle in [series] using [params] (already merged
  /// with defaults by the caller). Implementations should assume
  /// `series.length >= minCandles` — [evaluateSafe] guarantees that.
  StrategyResult evaluate(CandleSeries series, Map<String, num> params);

  /// Fills in any missing keys in [overrides] with this strategy's defaults.
  Map<String, num> mergeParams(Map<String, num>? overrides) {
    final merged = <String, num>{};
    for (final spec in paramSpecs) {
      merged[spec.key] = overrides?[spec.key] ?? spec.defaultValue;
    }
    return merged;
  }

  /// Public entry point used by both the live Signal Engine and the
  /// Backtesting Engine. Guarantees a strategy is never asked to evaluate
  /// on too little data (spec section 18: never crash on bad input) by
  /// returning a neutral result with an explanatory message instead.
  StrategyResult evaluateSafe(CandleSeries series, {Map<String, num>? overrides}) {
    final params = mergeParams(overrides);
    if (series.length < minCandles) {
      return StrategyResult(
        strategyId: id,
        direction: StrategyDirection.neutral,
        timestamp: series.isEmpty ? DateTime.now().toUtc() : series.last.timestamp,
        entryPriceRef: series.isEmpty ? 0 : series.last.close,
        indicatorValues: const {},
        explanation:
            'Insufficient candles to calculate $id (need $minCandles, have ${series.length}).',
      );
    }
    return evaluate(series, params);
  }
}
