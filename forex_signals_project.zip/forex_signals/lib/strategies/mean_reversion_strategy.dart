import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #23 — Mean Reversion. A z-score approach: how many standard deviations
/// is price away from its own moving average right now? Distinct from
/// Bollinger Bands (#8), which fires on the band *re-entry* cross — this
/// fires on the extreme itself, using a configurable threshold rather than
/// a fixed 2-standard-deviation band.
class MeanReversionStrategy extends Strategy {
  @override
  String get id => 'mean_reversion';

  @override
  int get minCandles => 40;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'Lookback period', defaultValue: 20, min: 10, max: 60),
        StrategyParamSpec(
            key: 'z_threshold', label: 'Z-score threshold', defaultValue: 2, min: 1, max: 4, step: 0.1, isInteger: false),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Mean Reversion',
        shortExplanation:
            'Measures how many standard deviations price has stretched from its own average, '
            'expecting a snap back.',
        indicatorsUsed: const ['Rolling mean', 'Rolling standard deviation (z-score)'],
        calculationLogic:
            'z-score = (close − rolling mean) ÷ rolling standard deviation, over the '
            'configured lookback period.',
        buyConditions: 'Z-score drops below the negative threshold (price unusually low '
            'relative to its recent average).',
        sellConditions: 'Z-score rises above the positive threshold (price unusually high '
            'relative to its recent average).',
        neutralConditions: 'Z-score is within the normal range.',
        suitableMarketConditions: 'Range-bound, mean-reverting markets without a strong trend.',
        typicalWeaknesses:
            'In a strongly trending market, price can remain at a stretched z-score for a long '
            'time — reversion is not guaranteed to happen quickly, or at all.',
        usualTimeframes: '15M, 1H',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final zThreshold = params['z_threshold']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final closes = series.closes;
    final mean = IndicatorEngine.memoize('$base|sma|$period', () => smaSeries(closes, period));
    final std = IndicatorEngine.memoize('$base|std|$period', () => rollingStdDev(closes, period));

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'Price is within the normal range of its recent average.';
    double? z;

    final m = mean[i], s = std[i];
    if (m != null && s != null && s > 0) {
      z = (last.close - m) / s;
      if (z <= -zThreshold) {
        direction = StrategyDirection.buy;
        reason = 'Price is ${z.abs().toStringAsFixed(2)} standard deviations below its '
            '$period-period average.';
      } else if (z >= zThreshold) {
        direction = StrategyDirection.sell;
        reason = 'Price is ${z.toStringAsFixed(2)} standard deviations above its '
            '$period-period average.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (m != null) 'mean': m,
        if (z != null) 'z_score': z,
      },
      explanation: reason,
    );
  }
}
