import 'package:flutter/material.dart';

import '../charts/candlestick_chart.dart';
import '../core/market_types.dart';
import '../indicators/adx.dart';
import '../indicators/atr.dart';
import '../indicators/bollinger_bands.dart';
import '../indicators/donchian.dart';
import '../indicators/ichimoku.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/macd.dart';
import '../indicators/moving_averages.dart';
import '../indicators/parabolic_sar.dart';
import '../indicators/pivot_points.dart';
import '../indicators/rsi.dart';
import '../indicators/stochastic.dart';
import '../indicators/stochastic_rsi.dart';
import '../indicators/supertrend.dart';
import '../indicators/vwap.dart';
import '../models/candle.dart';

/// A single labelled current-value readout, for strategies whose primary
/// indicator lives on an oscillator scale (0–100, or an unbounded
/// momentum/volatility number) rather than the price axis — RSI, MACD,
/// Stochastic, ADX and similar. Drawing those as a line on top of candle
/// prices would be meaningless (the scales don't match), so v1 shows their
/// current value as a compact badge above the chart instead of adding a
/// second stacked oscillator panel; see ARCHITECTURE.md's "known
/// limitations" for the reasoning and what a v2 panel would look like.
class ChartBadge {
  const ChartBadge({required this.label, required this.value, required this.color});
  final String label;
  final String value;
  final Color color;
}

class StrategyChartVisualization {
  const StrategyChartVisualization({this.lines = const [], this.bands = const [], this.badges = const []});
  final List<ChartOverlaySeries> lines;
  final List<ChartBandOverlay> bands;
  final List<ChartBadge> badges;
}

List<double?> _flatLine(int length, double? value) => List<double?>.filled(length, value);

/// Builds the visualization for one enabled strategy. [color] is assigned
/// by the chart screen (cycling through `AppColors.overlaySeries`) so
/// multiple simultaneously-enabled strategies stay visually distinguishable
/// — this function only decides *what shape* each strategy's visualization
/// takes, never its color.
StrategyChartVisualization buildOverlaysFor(
  String strategyId,
  CandleSeries series,
  Map<String, num> params,
  CurrencyPair pair,
  Color color,
) {
  if (series.isEmpty) return const StrategyChartVisualization();
  final base = IndicatorEngine.seriesKey(series, pair.code, 'overlay');
  final n = series.length;
  final last = n - 1;

  switch (strategyId) {
    case 'sma_crossover':
      final fast = Sma.compute(series, period: params['fast']!.toInt());
      final slow = Sma.compute(series, period: params['slow']!.toInt());
      return StrategyChartVisualization(lines: [
        ChartOverlaySeries(label: 'SMA fast', color: color, values: fast),
        ChartOverlaySeries(label: 'SMA slow', color: color, values: slow, dashed: true),
      ]);

    case 'ema_crossover':
    case 'ema_rsi_confirmation':
    case 'ema_macd_trend_confirmation':
    case 'ma_adx_trend': {
      final fastKey = strategyId == 'ema_crossover' || strategyId == 'ema_rsi_confirmation' ? 'fast' : 'ema_fast';
      final slowKey = strategyId == 'ema_crossover' || strategyId == 'ema_rsi_confirmation' ? 'slow' : 'ema_slow';
      final fast = Ema.compute(series, period: params[fastKey]!.toInt());
      final slow = Ema.compute(series, period: params[slowKey]!.toInt());
      final badges = <ChartBadge>[];
      if (strategyId == 'ema_rsi_confirmation') {
        final rsi = Rsi.compute(series, period: params['rsi_period']!.toInt());
        if (rsi[last] != null) badges.add(ChartBadge(label: 'RSI', value: rsi[last]!.toStringAsFixed(1), color: color));
      } else if (strategyId == 'ema_macd_trend_confirmation') {
        final macd = Macd.compute(series,
            fast: params['macd_fast']!.toInt(), slow: params['macd_slow']!.toInt(), signalPeriod: params['macd_signal']!.toInt());
        if (macd.histogram[last] != null) {
          badges.add(ChartBadge(label: 'MACD hist', value: macd.histogram[last]!.toStringAsFixed(5), color: color));
        }
      } else if (strategyId == 'ma_adx_trend') {
        final adx = Adx.compute(series, period: params['adx_period']!.toInt());
        if (adx.adx[last] != null) badges.add(ChartBadge(label: 'ADX', value: adx.adx[last]!.toStringAsFixed(1), color: color));
      }
      return StrategyChartVisualization(
        lines: [
          ChartOverlaySeries(label: 'EMA fast', color: color, values: fast),
          ChartOverlaySeries(label: 'EMA slow', color: color, values: slow, dashed: true),
        ],
        badges: badges,
      );
    }

    case 'bollinger_bands':
    case 'bollinger_band_squeeze': {
      final bb = BollingerBands.compute(series, period: params['period']!.toInt(), stdDevMultiple: params['std_dev']!.toDouble());
      return StrategyChartVisualization(
        lines: [ChartOverlaySeries(label: 'BB mid', color: color, values: bb.middle, dashed: true)],
        bands: [ChartBandOverlay(label: 'Bollinger Bands', color: color, upper: bb.upper, lower: bb.lower)],
      );
    }

    case 'donchian_breakout': {
      final d = Donchian.compute(series, period: params['period']!.toInt());
      return StrategyChartVisualization(
        bands: [ChartBandOverlay(label: 'Donchian', color: color, upper: d.upper, lower: d.lower)],
      );
    }

    case 'ichimoku_cloud': {
      final ich = Ichimoku.compute(series,
          tenkanPeriod: params['tenkan']!.toInt(),
          kijunPeriod: params['kijun']!.toInt(),
          senkouBPeriod: params['senkou_b']!.toInt(),
          displacement: params['displacement']!.toInt());
      return StrategyChartVisualization(
        lines: [
          ChartOverlaySeries(label: 'Tenkan', color: color, values: ich.tenkan),
          ChartOverlaySeries(label: 'Kijun', color: color, values: ich.kijun, dashed: true),
        ],
        bands: [ChartBandOverlay(label: 'Cloud', color: color, upper: ich.cloudTop, lower: ich.cloudBottom)],
      );
    }

    case 'parabolic_sar': {
      final sar = ParabolicSar.compute(series, step: params['step']!.toDouble(), maxAf: params['max_af']!.toDouble());
      return StrategyChartVisualization(lines: [ChartOverlaySeries(label: 'PSAR', color: color, values: sar)]);
    }

    case 'supertrend': {
      final st = Supertrend.compute(series, period: params['period']!.toInt(), multiplier: params['multiplier']!.toDouble());
      return StrategyChartVisualization(lines: [ChartOverlaySeries(label: 'Supertrend', color: color, values: st.line)]);
    }

    case 'vwap': {
      final v = Vwap.compute(series);
      return StrategyChartVisualization(lines: [ChartOverlaySeries(label: 'VWAP', color: color, values: v)]);
    }

    case 'pivot_point': {
      final p = PivotPoints.compute(series);
      return StrategyChartVisualization(lines: [
        ChartOverlaySeries(label: 'PP', color: color, values: p.pp),
        ChartOverlaySeries(label: 'R1', color: color, values: p.r1, dashed: true),
        ChartOverlaySeries(label: 'S1', color: color, values: p.s1, dashed: true),
      ]);
    }

    case 'support_resistance_breakout': {
      final leftRight = params['swing_left_right']!.toInt();
      final lookback = params['lookback']!.toInt();
      final start = (last - lookback + 1).clamp(0, last);
      final highsWindow = series.highs.sublist(start);
      final lowsWindow = series.lows.sublist(start);
      final swingHighs = findSwingHighIndices(highsWindow, leftRight: leftRight);
      final swingLows = findSwingLowIndices(lowsWindow, leftRight: leftRight);
      final lines = <ChartOverlaySeries>[];
      if (swingHighs.isNotEmpty) {
        lines.add(ChartOverlaySeries(label: 'Resistance', color: color, values: _flatLine(n, highsWindow[swingHighs.last])));
      }
      if (swingLows.isNotEmpty) {
        lines.add(ChartOverlaySeries(
            label: 'Support', color: color, values: _flatLine(n, lowsWindow[swingLows.last]), dashed: true));
      }
      return StrategyChartVisualization(lines: lines);
    }

    case 'mean_reversion': {
      final period = params['period']!.toInt();
      final mean = IndicatorEngine.memoize('$base|meanrev|$period', () => smaSeries(series.closes, period));
      final std = rollingStdDev(series.closes, period);
      final badges = <ChartBadge>[];
      if (mean[last] != null && std[last] != null && std[last]! > 0) {
        final z = (series.last.close - mean[last]!) / std[last]!;
        badges.add(ChartBadge(label: 'Z-score', value: z.toStringAsFixed(2), color: color));
      }
      return StrategyChartVisualization(
        lines: [ChartOverlaySeries(label: 'Mean', color: color, values: mean)],
        badges: badges,
      );
    }

    // --- Oscillator-scale strategies: badge only (see ChartBadge doc comment).
    case 'macd':
    case 'macd_rsi_confirmation': {
      final macd = Macd.compute(series,
          fast: params['fast']?.toInt() ?? params['macd_fast']!.toInt(),
          slow: params['slow']?.toInt() ?? params['macd_slow']!.toInt(),
          signalPeriod: params['signal']?.toInt() ?? params['macd_signal']!.toInt());
      final badges = [
        if (macd.macdLine[last] != null)
          ChartBadge(label: 'MACD', value: macd.macdLine[last]!.toStringAsFixed(5), color: color),
      ];
      if (strategyId == 'macd_rsi_confirmation') {
        final rsi = Rsi.compute(series, period: params['rsi_period']!.toInt());
        if (rsi[last] != null) badges.add(ChartBadge(label: 'RSI', value: rsi[last]!.toStringAsFixed(1), color: color));
      }
      return StrategyChartVisualization(badges: badges);
    }

    case 'rsi_overbought_oversold':
    case 'rsi_divergence': {
      final period = params['period']?.toInt() ?? params['rsi_period']!.toInt();
      final rsi = Rsi.compute(series, period: period);
      return StrategyChartVisualization(
        badges: [if (rsi[last] != null) ChartBadge(label: 'RSI', value: rsi[last]!.toStringAsFixed(1), color: color)],
      );
    }

    case 'stochastic': {
      final s = Stochastic.compute(series,
          period: params['period']!.toInt(), kSmoothing: params['k_smooth']!.toInt(), dPeriod: params['d_period']!.toInt());
      return StrategyChartVisualization(badges: [
        if (s.percentK[last] != null) ChartBadge(label: '%K', value: s.percentK[last]!.toStringAsFixed(1), color: color),
      ]);
    }

    case 'stochastic_rsi': {
      final s = StochasticRsi.compute(series,
          rsiPeriod: params['rsi_period']!.toInt(),
          stochPeriod: params['stoch_period']!.toInt(),
          kSmoothing: params['k_smooth']!.toInt(),
          dPeriod: params['d_period']!.toInt());
      return StrategyChartVisualization(badges: [
        if (s.percentK[last] != null) ChartBadge(label: 'StochRSI %K', value: s.percentK[last]!.toStringAsFixed(1), color: color),
      ]);
    }

    case 'atr_breakout': {
      final atr = Atr.compute(series, period: params['period']!.toInt());
      return StrategyChartVisualization(badges: [
        if (atr[last] != null) ChartBadge(label: 'ATR', value: pair.formatPrice(atr[last]!), color: color),
      ]);
    }

    case 'adx_di': {
      final adx = Adx.compute(series, period: params['period']!.toInt());
      return StrategyChartVisualization(badges: [
        if (adx.adx[last] != null) ChartBadge(label: 'ADX', value: adx.adx[last]!.toStringAsFixed(1), color: color),
      ]);
    }

    case 'momentum_breakout': {
      final roc = rocSeries(series.closes, params['period']!.toInt());
      return StrategyChartVisualization(badges: [
        if (roc[last] != null) ChartBadge(label: 'ROC', value: '${roc[last]!.toStringAsFixed(2)}%', color: color),
      ]);
    }

    default:
      return const StrategyChartVisualization();
  }
}
