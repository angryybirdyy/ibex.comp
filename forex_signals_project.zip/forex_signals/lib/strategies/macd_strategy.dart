import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/macd.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #3 — MACD. Classic trend/momentum signal from the MACD line crossing its
/// own signal line.
class MacdStrategy extends Strategy {
  @override
  String get id => 'macd';

  @override
  int get minCandles => 100;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'fast', label: 'Fast EMA', defaultValue: 12, min: 3, max: 50),
        StrategyParamSpec(key: 'slow', label: 'Slow EMA', defaultValue: 26, min: 10, max: 100),
        StrategyParamSpec(key: 'signal', label: 'Signal EMA', defaultValue: 9, min: 3, max: 50),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'MACD',
        shortExplanation:
            'Compares two EMAs via the MACD line and its signal line to catch momentum shifts.',
        indicatorsUsed: const ['MACD line', 'Signal line', 'Histogram'],
        calculationLogic:
            'MACD line = EMA(fast) − EMA(slow). Signal line = EMA(signal period) of the MACD '
            'line. Histogram = MACD line − signal line.',
        buyConditions: 'MACD line crosses above the signal line.',
        sellConditions: 'MACD line crosses below the signal line.',
        neutralConditions: 'No crossover on the current candle.',
        suitableMarketConditions: 'Trending markets with clear momentum.',
        typicalWeaknesses:
            'Lagging (built from EMAs) and prone to false signals during sideways, '
            'low-momentum conditions.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final fastP = params['fast']!.toInt();
    final slowP = params['slow']!.toInt();
    final signalP = params['signal']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final macd = IndicatorEngine.memoize(
      '$base|macd|$fastP|$slowP|$signalP',
      () => Macd.compute(series, fast: fastP, slow: slowP, signalPeriod: signalP),
    );

    final i = series.length - 1;
    final last = series.last;

    var direction = StrategyDirection.neutral;
    var reason = 'No MACD/signal crossover on this candle.';
    if (crossedAbove(macd.macdLine, macd.signalLine, i)) {
      direction = StrategyDirection.buy;
      reason = 'MACD line crossed above the signal line.';
    } else if (crossedBelow(macd.macdLine, macd.signalLine, i)) {
      direction = StrategyDirection.sell;
      reason = 'MACD line crossed below the signal line.';
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (macd.macdLine[i] != null) 'macd': macd.macdLine[i]!,
        if (macd.signalLine[i] != null) 'macd_signal': macd.signalLine[i]!,
        if (macd.histogram[i] != null) 'macd_hist': macd.histogram[i]!,
      },
      explanation: reason,
    );
  }
}
