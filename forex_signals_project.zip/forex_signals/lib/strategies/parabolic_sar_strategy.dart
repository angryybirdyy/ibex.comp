import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/parabolic_sar.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #14 — Parabolic SAR. A trend-following stop-and-reverse system; the
/// signal is the flip itself (SAR jumping to the other side of price).
class ParabolicSarStrategy extends Strategy {
  @override
  String get id => 'parabolic_sar';

  @override
  int get minCandles => 30;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'step', label: 'Acceleration step', defaultValue: 0.02, min: 0.01, max: 0.1, step: 0.01, isInteger: false),
        StrategyParamSpec(key: 'max_af', label: 'Max acceleration', defaultValue: 0.2, min: 0.1, max: 0.5, step: 0.01, isInteger: false),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Parabolic SAR',
        shortExplanation:
            'A trailing stop-and-reverse dot system; a signal fires exactly when the dot '
            'flips sides.',
        indicatorsUsed: const ['Parabolic SAR'],
        calculationLogic:
            'SAR trails price, accelerating toward it as the trend extends. When price crosses '
            'the SAR, the trend is considered to have reversed and SAR flips to the other side.',
        buyConditions: 'SAR flips from above price to below price (downtrend → uptrend).',
        sellConditions: 'SAR flips from below price to above price (uptrend → downtrend).',
        neutralConditions: 'No flip on the current candle.',
        suitableMarketConditions: 'Strongly trending markets.',
        typicalWeaknesses:
            'Whipsaws heavily in sideways/choppy markets, flipping back and forth with no '
            'real trend to follow.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final step = params['step']!.toDouble();
    final maxAf = params['max_af']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final sar = IndicatorEngine.memoize(
      '$base|psar|$step|$maxAf',
      () => ParabolicSar.compute(series, step: step, maxAf: maxAf),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No SAR flip on this candle.';

    if (i > 0 && sar[i - 1] != null && sar[i] != null) {
      final wasAbove = sar[i - 1]! > series[i - 1].close;
      final isAbove = sar[i]! > last.close;
      if (wasAbove && !isAbove) {
        direction = StrategyDirection.buy;
        reason = 'Parabolic SAR flipped below price — new uptrend.';
      } else if (!wasAbove && isAbove) {
        direction = StrategyDirection.sell;
        reason = 'Parabolic SAR flipped above price — new downtrend.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {if (sar[i] != null) 'sar': sar[i]!},
      explanation: reason,
    );
  }
}
