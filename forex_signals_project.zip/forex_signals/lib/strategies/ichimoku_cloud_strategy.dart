import '../core/enums.dart';
import '../indicators/ichimoku.dart';
import '../indicators/indicator_engine.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #12 — Ichimoku Cloud. Combines three confirmations that all have to
/// agree: price breaking through the cloud, the Tenkan/Kijun (conversion
/// /base line) alignment, and the cloud's own color (Senkou A vs B).
class IchimokuCloudStrategy extends Strategy {
  @override
  String get id => 'ichimoku_cloud';

  @override
  int get minCandles => 160;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'tenkan', label: 'Tenkan period', defaultValue: 9, min: 3, max: 20),
        StrategyParamSpec(key: 'kijun', label: 'Kijun period', defaultValue: 26, min: 10, max: 60),
        StrategyParamSpec(key: 'senkou_b', label: 'Senkou B period', defaultValue: 52, min: 20, max: 120),
        StrategyParamSpec(key: 'displacement', label: 'Cloud displacement', defaultValue: 26, min: 10, max: 60),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Ichimoku Cloud',
        shortExplanation:
            'A multi-part Japanese trend system: price vs. the cloud, plus two moving '
            'baselines, all have to agree.',
        indicatorsUsed: const ['Tenkan-sen', 'Kijun-sen', 'Senkou Span A/B (cloud)'],
        calculationLogic:
            'Tenkan = midpoint of 9-period high/low. Kijun = midpoint of 26-period high/low. '
            'The cloud (Senkou A/B) is the midpoint of Tenkan/Kijun and of the 52-period '
            'high/low respectively, plotted 26 bars ahead.',
        buyConditions:
            'Price closes above the cloud, Tenkan is above Kijun, and the cloud itself is '
            'bullish (Senkou A above Senkou B).',
        sellConditions:
            'Price closes below the cloud, Tenkan is below Kijun, and the cloud itself is '
            'bearish (Senkou A below Senkou B).',
        neutralConditions: 'Price is inside the cloud, or the conditions disagree.',
        suitableMarketConditions: 'Trending markets; the cloud itself acts as dynamic '
            'support/resistance.',
        typicalWeaknesses:
            'Needs a long history to compute (52+26 candles) and reacts slowly due to the '
            'displacement — not well suited to fast scalping.',
        usualTimeframes: '4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final tenkanP = params['tenkan']!.toInt();
    final kijunP = params['kijun']!.toInt();
    final senkouBP = params['senkou_b']!.toInt();
    final disp = params['displacement']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final ich = IndicatorEngine.memoize(
      '$base|ichimoku|$tenkanP|$kijunP|$senkouBP|$disp',
      () => Ichimoku.compute(series,
          tenkanPeriod: tenkanP, kijunPeriod: kijunP, senkouBPeriod: senkouBP, displacement: disp),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'Price is inside the cloud, or trend signals disagree.';

    if (i > 0 && i - disp >= 0) {
      final top0 = ich.cloudTop[i - 1], top1 = ich.cloudTop[i];
      final bot0 = ich.cloudBottom[i - 1], bot1 = ich.cloudBottom[i];
      final tenkan = ich.tenkan[i], kijun = ich.kijun[i];
      final aRaw = ich.senkouARaw[i - disp], bRaw = ich.senkouBRaw[i - disp];
      final close0 = series[i - 1].close, close1 = last.close;

      if (top0 != null &&
          top1 != null &&
          tenkan != null &&
          kijun != null &&
          aRaw != null &&
          bRaw != null &&
          close0 <= top0 &&
          close1 > top1 &&
          tenkan > kijun &&
          aRaw > bRaw) {
        direction = StrategyDirection.buy;
        reason = 'Price broke above the cloud with Tenkan > Kijun and a bullish cloud.';
      } else if (bot0 != null &&
          bot1 != null &&
          tenkan != null &&
          kijun != null &&
          aRaw != null &&
          bRaw != null &&
          close0 >= bot0 &&
          close1 < bot1 &&
          tenkan < kijun &&
          aRaw < bRaw) {
        direction = StrategyDirection.sell;
        reason = 'Price broke below the cloud with Tenkan < Kijun and a bearish cloud.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (ich.tenkan[i] != null) 'tenkan': ich.tenkan[i]!,
        if (ich.kijun[i] != null) 'kijun': ich.kijun[i]!,
        if (ich.cloudTop[i] != null) 'cloud_top': ich.cloudTop[i]!,
        if (ich.cloudBottom[i] != null) 'cloud_bottom': ich.cloudBottom[i]!,
      },
      explanation: reason,
    );
  }
}
