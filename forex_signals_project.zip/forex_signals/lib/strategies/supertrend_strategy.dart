import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/supertrend.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #15 — Supertrend. An ATR-based trailing trend line; the signal is the
/// line flipping sides, similar in spirit to Parabolic SAR (#14) but built
/// directly from ATR bands rather than an accelerating step function.
class SupertrendStrategy extends Strategy {
  @override
  String get id => 'supertrend';

  @override
  int get minCandles => 40;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'period', label: 'ATR period', defaultValue: 10, min: 5, max: 30),
        StrategyParamSpec(
            key: 'multiplier', label: 'ATR multiplier', defaultValue: 3, min: 1, max: 6, step: 0.5, isInteger: false),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'Supertrend',
        shortExplanation: 'An ATR-based trend line that flips sides when the trend reverses.',
        indicatorsUsed: const ['ATR', 'Supertrend line'],
        calculationLogic:
            'Upper/lower bands are set at `(high+low)/2 ± multiplier × ATR`, then only allowed '
            'to move toward price. The active line flips to the other band once price closes '
            'through it.',
        buyConditions: 'Supertrend line flips from above price to below price.',
        sellConditions: 'Supertrend line flips from below price to above price.',
        neutralConditions: 'No flip on the current candle.',
        suitableMarketConditions: 'Trending markets; also usable as a visual trailing stop.',
        typicalWeaknesses:
            'Like other trend-following stop systems, it whipsaws in sideways/choppy markets.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final period = params['period']!.toInt();
    final multiplier = params['multiplier']!.toDouble();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final st = IndicatorEngine.memoize(
      '$base|supertrend|$period|$multiplier',
      () => Supertrend.compute(series, period: period, multiplier: multiplier),
    );

    final i = series.length - 1;
    final last = series.last;
    var direction = StrategyDirection.neutral;
    var reason = 'No Supertrend flip on this candle.';

    if (i > 0 && st.isUptrend[i - 1] != null && st.isUptrend[i] != null) {
      final wasUp = st.isUptrend[i - 1]!;
      final isUp = st.isUptrend[i]!;
      if (!wasUp && isUp) {
        direction = StrategyDirection.buy;
        reason = 'Supertrend flipped to an uptrend.';
      } else if (wasUp && !isUp) {
        direction = StrategyDirection.sell;
        reason = 'Supertrend flipped to a downtrend.';
      }
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {if (st.line[i] != null) 'supertrend': st.line[i]!},
      explanation: reason,
    );
  }
}
