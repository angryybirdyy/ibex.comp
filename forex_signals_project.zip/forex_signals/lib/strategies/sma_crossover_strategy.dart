import '../core/enums.dart';
import '../indicators/indicator_engine.dart';
import '../indicators/indicator_utils.dart';
import '../indicators/moving_averages.dart';
import '../models/candle.dart';
import '../models/strategy_meta.dart';
import '../models/strategy_result.dart';
import 'strategy.dart';

/// #1 — SMA Crossover. Only [id], [meta], [paramSpecs], [minCandles] and
/// [evaluate] are strategy-specific; `mergeParams`/`evaluateSafe` are
/// inherited from [Strategy].
class SmaCrossoverStrategy extends Strategy {
  @override
  String get id => 'sma_crossover';

  @override
  int get minCandles => 60;

  @override
  List<StrategyParamSpec> get paramSpecs => const [
        StrategyParamSpec(key: 'fast', label: 'Fast period', defaultValue: 10, min: 3, max: 50),
        StrategyParamSpec(key: 'slow', label: 'Slow period', defaultValue: 30, min: 10, max: 200),
      ];

  @override
  StrategyMeta get meta => StrategyMeta(
        id: id,
        name: 'SMA Crossover',
        shortExplanation:
            'Follows the trend by comparing a fast and a slow simple moving average.',
        indicatorsUsed: const ['SMA (fast)', 'SMA (slow)'],
        calculationLogic:
            'Computes two Simple Moving Averages of closing price, one short-period '
            '(fast) and one long-period (slow), and watches for the fast line '
            'crossing the slow line.',
        buyConditions: 'Fast SMA crosses above slow SMA (golden cross).',
        sellConditions: 'Fast SMA crosses below slow SMA (death cross).',
        neutralConditions: 'No crossover on the current candle.',
        suitableMarketConditions: 'Trending markets with sustained directional moves.',
        typicalWeaknesses:
            'Lags price (both averages are backward-looking) and whipsaws in sideways, '
            'choppy conditions, producing false signals.',
        usualTimeframes: '1H, 4H, 1D',
      );

  @override
  StrategyResult evaluate(CandleSeries series, Map<String, num> params) {
    final fastP = params['fast']!.toInt();
    final slowP = params['slow']!.toInt();
    final base = IndicatorEngine.seriesKey(series, 'any', 'any');
    final fast =
        IndicatorEngine.memoize('$base|sma|$fastP', () => Sma.compute(series, period: fastP));
    final slow =
        IndicatorEngine.memoize('$base|sma|$slowP', () => Sma.compute(series, period: slowP));

    final i = series.length - 1;
    final last = series.last;

    var direction = StrategyDirection.neutral;
    var reason = 'No SMA crossover on this candle.';
    if (crossedAbove(fast, slow, i)) {
      direction = StrategyDirection.buy;
      reason = 'Fast SMA($fastP) crossed above slow SMA($slowP).';
    } else if (crossedBelow(fast, slow, i)) {
      direction = StrategyDirection.sell;
      reason = 'Fast SMA($fastP) crossed below slow SMA($slowP).';
    }

    return StrategyResult(
      strategyId: id,
      direction: direction,
      timestamp: last.timestamp,
      entryPriceRef: last.close,
      indicatorValues: {
        if (fast[i] != null) 'sma_fast': fast[i]!,
        if (slow[i] != null) 'sma_slow': slow[i]!,
      },
      explanation: reason,
    );
  }
}
