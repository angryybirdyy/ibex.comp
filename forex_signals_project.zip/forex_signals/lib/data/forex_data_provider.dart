import '../core/failures.dart';
import '../core/market_types.dart';
import '../models/candle.dart';

/// The seam the whole app talks to for market data (spec section 18/48).
/// Two implementations exist today — [DemoDataProvider] and
/// [TwelveDataProvider] — selected by `data/provider_factory.dart` based on
/// the user's Settings choice. Adding provider #3 means implementing this
/// interface and adding one case to the factory; nothing else in the app
/// (repository, indicators, strategies, UI) references a provider directly.
abstract class ForexDataProvider {
  /// Display name shown in Settings, e.g. "Demo (synthetic data)" or
  /// "Twelve Data".
  String get name;

  /// Whether this provider needs an API key to function.
  bool get requiresApiKey;

  /// Latest tradable price for [pair]. Used for the "current price" header
  /// and to mark signals' current market price.
  Future<Result<double>> getCurrentPrice(CurrencyPair pair);

  /// Historical + most-recent OHLC candles for (pair, timeframe), newest
  /// [outputSize] candles, oldest first. Implementations must not fabricate
  /// candles: on any failure, return an [Err], never synthesized data
  /// dressed up as real.
  Future<Result<List<Candle>>> getCandles(
    CurrencyPair pair,
    Timeframe timeframe, {
    required int outputSize,
  });
}
