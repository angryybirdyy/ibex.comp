import '../core/failures.dart';
import '../core/logger.dart';
import '../core/market_types.dart';
import '../database/candle_dao.dart';
import '../database/sync_state_dao.dart';
import '../models/candle.dart';
import '../services/connectivity_service.dart';
import 'forex_data_provider.dart';

/// The `HistoricalDataRepository` from the architecture diagram in
/// ARCHITECTURE.md: the only place that talks to both a [ForexDataProvider]
/// and the candle database. Everything above this layer (indicators,
/// strategies, charts) reads candles from here, never from a provider
/// directly — so it never has to care whether data came from the network
/// just now or from yesterday's cache.
class MarketDataRepository {
  MarketDataRepository({
    required CandleDao candleDao,
    required SyncStateDao syncStateDao,
    required ForexDataProvider Function() providerGetter,
  })  : _candleDao = candleDao,
        _syncStateDao = syncStateDao,
        _providerGetter = providerGetter;

  final CandleDao _candleDao;
  final SyncStateDao _syncStateDao;
  final ForexDataProvider Function() _providerGetter;
  static const String _tag = 'MarketDataRepository';

  /// Fetches fresh candles for (pair, timeframe) and merges them into the
  /// local cache. Returns the failure (if any) so callers can update a
  /// service-status indicator, but never throws — a failed sync just means
  /// the cached data (if any) stays as the most recent known state (spec
  /// section 20: never crash on a failed request, keep showing what we have).
  Future<AppFailure?> syncPairTimeframe(CurrencyPair pair, Timeframe timeframe, {int outputSize = 200}) async {
    if (!await ConnectivityService.instance.isOnline()) {
      await _syncStateDao.recordError(pair.code, timeframe.label, 'offline');
      return const NoConnectionFailure();
    }

    final provider = _providerGetter();
    final result = await provider.getCandles(pair, timeframe, outputSize: outputSize);
    return result.when(
      ok: (candles) async {
        if (candles.isEmpty) {
          await _syncStateDao.recordError(pair.code, timeframe.label, 'empty response');
          return const HistoricalDataUnavailableFailure();
        }
        await _candleDao.upsertCandles(pair.code, timeframe.label, candles);
        await _syncStateDao.recordSuccess(
          pair.code,
          timeframe.label,
          syncedAtUtc: DateTime.now().toUtc(),
          latestCandleUtc: candles.last.timestamp,
        );
        final gaps = await _candleDao.findGaps(pair.code, timeframe.label, timeframe.minutes);
        if (gaps.isNotEmpty) {
          AppLogger.instance.warn(_tag,
              '${pair.code} ${timeframe.label}: ${gaps.length} missing candle(s) detected (oldest gap ${gaps.first}).');
        }
        return null;
      },
      err: (failure) async {
        AppLogger.instance.warn(_tag, '${pair.code} ${timeframe.label} sync failed: ${failure.friendlyMessage}');
        await _syncStateDao.recordError(pair.code, timeframe.label, failure.friendlyMessage);
        return failure;
      },
    );
  }

  /// Syncs every (pair, timeframe) combination sequentially — deliberately
  /// not in parallel, so a shared provider rate limit is respected as a
  /// steady trickle of requests rather than a burst (spec section 30).
  Future<Map<String, AppFailure?>> syncAll(List<CurrencyPair> pairs, List<Timeframe> timeframes) async {
    final results = <String, AppFailure?>{};
    for (final pair in pairs) {
      for (final tf in timeframes) {
        results['${pair.code}_${tf.label}'] = await syncPairTimeframe(pair, tf);
      }
    }
    return results;
  }

  /// Reads candles from the local cache (works fully offline). This is what
  /// charts, indicators, strategies, and the backtester all call — never
  /// [ForexDataProvider] directly.
  Future<CandleSeries> getSeries(CurrencyPair pair, Timeframe timeframe, {int? limit}) {
    return _candleDao.getCandles(pair.code, timeframe.label, limit: limit);
  }

  Future<double?> getLatestCachedPrice(CurrencyPair pair, Timeframe timeframe) async {
    final candle = await _candleDao.getLatestCandle(pair.code, timeframe.label);
    return candle?.close;
  }

  Future<SyncState> getSyncState(CurrencyPair pair, Timeframe timeframe) {
    return _syncStateDao.get(pair.code, timeframe.label);
  }
}
