import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/failures.dart';
import '../core/logger.dart';
import '../core/market_types.dart';
import '../models/candle.dart';
import 'forex_data_provider.dart';
import 'rate_limiter.dart';

/// Live market data via Twelve Data (https://twelvedata.com/docs). Chosen
/// for this project because its free tier explicitly covers forex OHLC
/// candles at every interval the app needs (1min…1day) with a documented,
/// predictable per-minute credit limit — verify current limits/pricing at
/// https://twelvedata.com/pricing before relying on this in production,
/// since providers change their terms over time (spec section 48).
///
/// This is one implementation of [ForexDataProvider]; nothing outside
/// `data/provider_factory.dart` references this class directly, so
/// switching providers later means writing a new class against the same
/// interface.
class TwelveDataProvider implements ForexDataProvider {
  TwelveDataProvider({required this.apiKeyGetter, RateLimiter? rateLimiter})
      : _rateLimiter = rateLimiter ??
            RateLimiter(capacity: 8, refillWindow: const Duration(minutes: 1));

  static const String _baseUrl = 'https://api.twelvedata.com';

  /// Reads the current key from secure storage each call, so a key entered
  /// or changed in Settings takes effect immediately without recreating
  /// this provider.
  final Future<String?> Function() apiKeyGetter;

  final RateLimiter _rateLimiter;

  @override
  String get name => 'Twelve Data';

  @override
  bool get requiresApiKey => true;

  Uri _uri(String path, Map<String, String> query) => Uri.parse('$_baseUrl$path').replace(
        queryParameters: query,
      );

  /// Strips the API key before this URL is ever used in a log line (spec
  /// sections 32/36: never log API keys).
  String _redacted(Uri uri) {
    final safe = Map<String, String>.from(uri.queryParameters)..remove('apikey');
    return uri.replace(queryParameters: safe).toString();
  }

  Future<Result<Map<String, dynamic>>> _getJson(
    String path,
    Map<String, String> query, {
    required int creditCost,
  }) async {
    final apiKey = await apiKeyGetter();
    if (apiKey == null || apiKey.isEmpty) {
      return const Result.err(MissingApiKeyFailure());
    }

    if (!_rateLimiter.tryConsume(creditCost)) {
      final wait = _rateLimiter.timeUntilAvailable(creditCost);
      AppLogger.instance.warn('TwelveDataProvider', 'Rate-limited locally, retry in $wait');
      return Result.err(RateLimitedFailure(wait));
    }

    final uri = _uri(path, {...query, 'apikey': apiKey, 'format': 'JSON'});
    const maxAttempts = 3;
    const backoffs = [Duration(milliseconds: 500), Duration(seconds: 2)];

    for (int attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        final response = await http.get(uri).timeout(const Duration(seconds: 15));
        if (response.statusCode == 429) {
          return const Result.err(RateLimitedFailure(Duration(minutes: 1)));
        }
        if (response.statusCode == 401 || response.statusCode == 403) {
          return const Result.err(InvalidApiKeyFailure());
        }
        if (response.statusCode >= 500) {
          // Transient server-side failure — worth a retry with backoff.
          AppLogger.instance.warn('TwelveDataProvider',
              'Server error ${response.statusCode} on ${_redacted(uri)}, attempt ${attempt + 1}');
          if (attempt < backoffs.length) {
            await Future.delayed(backoffs[attempt]);
            continue;
          }
          return const Result.err(InvalidResponseFailure('server 5xx after retries'));
        }
        if (response.statusCode != 200) {
          return Result.err(InvalidResponseFailure('HTTP ${response.statusCode}'));
        }

        final decoded = jsonDecode(response.body);
        if (decoded is! Map<String, dynamic>) {
          return const Result.err(InvalidResponseFailure('unexpected response shape'));
        }
        if (decoded['status'] == 'error') {
          final code = decoded['code'];
          if (code == 429) return const Result.err(RateLimitedFailure(Duration(minutes: 1)));
          if (code == 401 || code == 403) return const Result.err(InvalidApiKeyFailure());
          AppLogger.instance.warn('TwelveDataProvider', 'API error: ${decoded['message']}');
          return Result.err(InvalidResponseFailure('${decoded['message']}'));
        }
        return Result.ok(decoded);
      } on TimeoutException {
        AppLogger.instance.warn('TwelveDataProvider', 'Timeout on ${_redacted(uri)}, attempt ${attempt + 1}');
        if (attempt < backoffs.length) {
          await Future.delayed(backoffs[attempt]);
          continue;
        }
        return const Result.err(TimeoutFailure());
      } catch (e) {
        // Covers SocketException and friends without importing dart:io
        // (keeps this file platform-agnostic for the ffi-based unit tests).
        final msg = e.toString();
        final looksOffline = msg.contains('SocketException') ||
            msg.contains('Failed host lookup') ||
            msg.contains('Network is unreachable');
        if (looksOffline) return const Result.err(NoConnectionFailure());
        AppLogger.instance.error('TwelveDataProvider', 'Unexpected error calling ${_redacted(uri)}', e);
        if (attempt < backoffs.length) {
          await Future.delayed(backoffs[attempt]);
          continue;
        }
        return Result.err(UnknownFailure(msg));
      }
    }
    return const Result.err(UnknownFailure('exhausted retries'));
  }

  @override
  Future<Result<double>> getCurrentPrice(CurrencyPair pair) async {
    final result = await _getJson('/price', {'symbol': pair.displaySymbol}, creditCost: 1);
    return result.when(
      ok: (json) {
        final raw = json['price'];
        final price = raw is String ? double.tryParse(raw) : (raw as num?)?.toDouble();
        if (price == null) return const Result.err(InvalidResponseFailure('missing price field'));
        return Result.ok(price);
      },
      err: (f) => Result.err(f),
    );
  }

  @override
  Future<Result<List<Candle>>> getCandles(
    CurrencyPair pair,
    Timeframe timeframe, {
    required int outputSize,
  }) async {
    final result = await _getJson(
      '/time_series',
      {
        'symbol': pair.displaySymbol,
        'interval': timeframe.apiInterval,
        'outputsize': outputSize.clamp(1, 5000).toString(),
        'timezone': 'UTC',
      },
      creditCost: 1,
    );

    return result.when(
      ok: (json) {
        final values = json['values'];
        if (values is! List) {
          return const Result.err(HistoricalDataUnavailableFailure());
        }
        try {
          return Result.ok(parseCandlesFromJson(values));
        } catch (e) {
          AppLogger.instance.error('TwelveDataProvider', 'Failed to parse candle payload', e);
          return const Result.err(InvalidResponseFailure('candle parse error'));
        }
      },
      err: (f) => Result.err(f),
    );
  }

  /// Pure parsing logic, factored out so it's unit-testable with a plain
  /// JSON fixture and no network/HTTP mocking (spec section 34: "data
  /// parsing" is one of the required unit-test categories). This is the
  /// exact code path [getCandles] uses — the test exercises production
  /// logic, not a reimplementation of it.
  static List<Candle> parseCandlesFromJson(List<dynamic> values) {
    final candles = values.map<Candle>((raw) {
      final m = raw as Map<String, dynamic>;
      // Twelve Data returns "YYYY-MM-DD HH:mm:ss" in the requested
      // timezone (UTC, per the query's timezone=UTC param) with no offset
      // suffix, so a literal "Z" is appended before parsing as UTC.
      final ts = DateTime.parse('${m['datetime']}Z'.replaceFirst(' ', 'T'));
      return Candle(
        timestamp: ts.toUtc(),
        open: double.parse(m['open'] as String),
        high: double.parse(m['high'] as String),
        low: double.parse(m['low'] as String),
        close: double.parse(m['close'] as String),
        volume: double.tryParse((m['volume'] as String?) ?? '0') ?? 0,
        isDemo: false,
      );
    }).toList();
    // Twelve Data returns newest-first; the rest of the app expects
    // chronological (oldest-first) order.
    candles.sort((a, b) => a.timestamp.compareTo(b.timestamp));
    return candles;
  }
}
