import '../core/enums.dart';
import '../core/market_types.dart';
import '../models/candle.dart';

class TpSlLevels {
  const TpSlLevels({required this.target, required this.stopLoss});
  final double target;
  final double stopLoss;
}

/// Computes TP/SL levels for a new signal (spec section 12/23).
///
///  - [TpSlMethod.atrMultiple] (default): distance = `atrValue × atrMultiple`,
///    so targets automatically widen/narrow with current volatility. Falls
///    back to the fixed-pips method if ATR isn't available yet (e.g. very
///    early in a series) so a signal is never left without levels.
///  - [TpSlMethod.fixedPips]: distance = `fixedPips × pair.pipSize`.
TpSlLevels computeTpSl({
  required SignalDirection direction,
  required double entryPrice,
  required CurrencyPair pair,
  required TpSlMethod method,
  double? atrValue,
  required double atrMultiple,
  required double fixedPips,
}) {
  double distance;
  if (method == TpSlMethod.atrMultiple && atrValue != null && atrValue > 0) {
    distance = atrValue * atrMultiple;
  } else {
    distance = fixedPips * pair.pipSize;
  }
  if (direction == SignalDirection.buy) {
    return TpSlLevels(target: entryPrice + distance, stopLoss: entryPrice - distance);
  } else {
    return TpSlLevels(target: entryPrice - distance, stopLoss: entryPrice + distance);
  }
}

class EvaluationOutcome {
  const EvaluationOutcome({required this.result, this.exitTime, this.exitPrice});
  final SignalResultType result;
  final DateTime? exitTime;
  final double? exitPrice;
}

/// Walks [futureCandles] (chronological, all strictly after the signal's
/// own candle) looking for the first candle whose high/low touches the
/// target or stop-loss (spec section 13).
///
/// **Documented assumption**: OHLC candles don't record the order prices
/// moved *within* a candle. If a single candle's range contains *both*
/// levels, we can't know from OHLC alone which was actually touched first.
/// This function resolves that (rare but real) ambiguity by assuming
/// whichever level is *closer to that candle's open* was reached first —
/// a standard, conservative simplifying assumption used by OHLC-based
/// backtesters generally. It is applied identically for live signal
/// resolution and for backtesting, so results stay comparable, and it is
/// disclosed here rather than silently picked.
EvaluationOutcome evaluateSignalOutcome({
  required SignalDirection direction,
  required double target,
  required double stopLoss,
  required List<Candle> futureCandles,
}) {
  for (final c in futureCandles) {
    final hitTp = direction == SignalDirection.buy ? c.high >= target : c.low <= target;
    final hitSl = direction == SignalDirection.buy ? c.low <= stopLoss : c.high >= stopLoss;

    if (hitTp && hitSl) {
      final distTp = (target - c.open).abs();
      final distSl = (stopLoss - c.open).abs();
      if (distTp <= distSl) {
        return EvaluationOutcome(result: SignalResultType.win, exitTime: c.timestamp, exitPrice: target);
      } else {
        return EvaluationOutcome(result: SignalResultType.loss, exitTime: c.timestamp, exitPrice: stopLoss);
      }
    } else if (hitTp) {
      return EvaluationOutcome(result: SignalResultType.win, exitTime: c.timestamp, exitPrice: target);
    } else if (hitSl) {
      return EvaluationOutcome(result: SignalResultType.loss, exitTime: c.timestamp, exitPrice: stopLoss);
    }
  }
  return const EvaluationOutcome(result: SignalResultType.unresolved);
}
