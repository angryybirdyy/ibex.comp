import 'package:flutter/material.dart';

import 'app.dart';
import 'services/background_service.dart';
import 'services/notification_service.dart';
import 'state/app_services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Order matters: notifications before background service (the service's
  // first cycle may want to notify immediately), and both before the
  // database-backed AppServices bootstrap so nothing races the very first
  // frame.
  await NotificationService.instance.initialize();
  await BackgroundService.initialize();
  final appServices = await AppServices.bootstrap();

  runApp(ForexSignalsRoot(appServices: appServices));
}
