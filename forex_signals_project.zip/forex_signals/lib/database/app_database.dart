import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../core/logger.dart';
import 'tables.dart';

/// Opens (and, on first run, creates) the app's single SQLite database.
///
/// Tests use `sqflite_common_ffi` and set `databaseFactory` themselves
/// before calling [open] (see `test/database/db_test_utils.dart`), so this
/// class never assumes it's running on a real Android device.
class AppDatabase {
  AppDatabase._(this.db);

  final Database db;

  static AppDatabase? _instance;

  /// Returns the shared instance, opening it on first call. Safe to call
  /// repeatedly — later calls are no-ops once opened.
  static Future<AppDatabase> open({String? overridePath}) async {
    if (_instance != null) return _instance!;
    final path = overridePath ?? p.join(await getDatabasesPath(), dbFileName);
    final db = await databaseFactory.openDatabase(
      path,
      options: OpenDatabaseOptions(
        version: dbVersion,
        onCreate: (db, version) async {
          for (final stmt in allCreateStatements) {
            await db.execute(stmt);
          }
          AppLogger.instance.info('AppDatabase', 'Created schema v$version at $path');
        },
        onUpgrade: (db, oldVersion, newVersion) async {
          AppLogger.instance.info('AppDatabase', 'Upgrading schema $oldVersion -> $newVersion');
          // No migrations yet — v1 is the first shipped schema. Future
          // migrations get their own numbered `if (oldVersion < N)` block
          // here, each containing only additive ALTER/CREATE statements so
          // existing candle/signal history is never destroyed by an update.
        },
      ),
    );
    _instance = AppDatabase._(db);
    return _instance!;
  }

  static Future<void> closeForTests() async {
    await _instance?.db.close();
    _instance = null;
  }
}
