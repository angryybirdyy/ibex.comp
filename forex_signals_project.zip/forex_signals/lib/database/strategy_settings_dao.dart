import 'package:sqflite/sqflite.dart';

import 'app_database.dart';

/// Persists two independent things per strategy (spec sections 9 & 23):
///  - `chart_enabled`: whether the strategy's overlays show on the charts.
///    This is a *display* toggle only and never affects the Signal Engine
///    (see `signals/signal_engine.dart`, which reads directly from
///    `StrategyRegistry.all` regardless of this table).
///  - configurable numeric parameter overrides (RSI period, EMA lengths…).
class StrategySettingsDao {
  StrategySettingsDao(this._appDb);
  final AppDatabase _appDb;

  Future<Map<String, bool>> getAllChartEnabled() async {
    final rows = await _appDb.db.query('strategy_selection');
    return {for (final r in rows) r['strategy_id'] as String: (r['chart_enabled'] as int) == 1};
  }

  Future<void> setChartEnabled(String strategyId, bool enabled) async {
    await _appDb.db.insert(
      'strategy_selection',
      {'strategy_id': strategyId, 'chart_enabled': enabled ? 1 : 0},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> setAllChartEnabled(Iterable<String> strategyIds, bool enabled) async {
    final batch = _appDb.db.batch();
    for (final id in strategyIds) {
      batch.insert(
        'strategy_selection',
        {'strategy_id': id, 'chart_enabled': enabled ? 1 : 0},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<void> clearAllSelections() async {
    await _appDb.db.delete('strategy_selection');
  }

  Future<Map<String, num>> getParamOverrides(String strategyId) async {
    final rows = await _appDb.db.query('strategy_params', where: 'strategy_id = ?', whereArgs: [strategyId]);
    return {for (final r in rows) r['param_key'] as String: r['value'] as num};
  }

  Future<void> setParam(String strategyId, String key, num value) async {
    await _appDb.db.insert(
      'strategy_params',
      {'strategy_id': strategyId, 'param_key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> resetParams(String strategyId) async {
    await _appDb.db.delete('strategy_params', where: 'strategy_id = ?', whereArgs: [strategyId]);
  }

  Future<void> resetAllParams() async {
    await _appDb.db.delete('strategy_params');
  }
}
