import 'package:sqflite/sqflite.dart';

import '../core/time_utils.dart';
import '../models/candle.dart';
import 'app_database.dart';

class CandleDao {
  CandleDao(this._appDb);
  final AppDatabase _appDb;

  /// Inserts or replaces candles for (pair, timeframe). `REPLACE` on the
  /// (pair, timeframe, ts) primary key is exactly the spec's required
  /// "duplicate candle" handling — a re-fetched candle for a timestamp we
  /// already have simply overwrites it (e.g. with a now-finalized close)
  /// rather than creating a second row.
  Future<void> upsertCandles(String pair, String timeframe, List<Candle> candles) async {
    if (candles.isEmpty) return;
    final batch = _appDb.db.batch();
    for (final c in candles) {
      batch.insert(
        'candles',
        c.toMap(pair, timeframe),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  /// Returns candles in chronological order (oldest first). If [limit] is
  /// given, returns the most recent [limit] candles (still chronological).
  Future<CandleSeries> getCandles(
    String pair,
    String timeframe, {
    int? limit,
    DateTime? sinceUtc,
  }) async {
    final where = StringBuffer('pair = ? AND timeframe = ?');
    final args = <Object?>[pair, timeframe];
    if (sinceUtc != null) {
      where.write(' AND ts >= ?');
      args.add(toStorageString(sinceUtc));
    }
    final rows = await _appDb.db.query(
      'candles',
      where: where.toString(),
      whereArgs: args,
      orderBy: 'ts DESC',
      limit: limit,
    );
    final candles = rows.map(Candle.fromMap).toList().reversed.toList();
    return CandleSeries(candles);
  }

  Future<Candle?> getLatestCandle(String pair, String timeframe) async {
    final rows = await _appDb.db.query(
      'candles',
      where: 'pair = ? AND timeframe = ?',
      whereArgs: [pair, timeframe],
      orderBy: 'ts DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Candle.fromMap(rows.first);
  }

  Future<int> countCandles(String pair, String timeframe) async {
    final result = await _appDb.db.rawQuery(
      'SELECT COUNT(*) AS c FROM candles WHERE pair = ? AND timeframe = ?',
      [pair, timeframe],
    );
    return Sqflite.firstIntValue(result) ?? 0;
  }

  /// Scans stored candles between the oldest and newest we have and returns
  /// the start-times of any missing candle slots (spec section 18: "missing
  /// candles"). The repository decides what to do with the result (e.g.
  /// request a targeted backfill) — this DAO only detects the gap.
  Future<List<DateTime>> findGaps(String pair, String timeframe, int intervalMinutes) async {
    final series = await getCandles(pair, timeframe);
    if (series.length < 2) return const [];
    final missing = <DateTime>[];
    final step = Duration(minutes: intervalMinutes);
    for (int i = 1; i < series.length; i++) {
      var expected = series[i - 1].timestamp.add(step);
      while (expected.isBefore(series[i].timestamp)) {
        missing.add(expected);
        expected = expected.add(step);
      }
    }
    return missing;
  }

  Future<void> deleteAll(String pair, String timeframe) async {
    await _appDb.db.delete('candles', where: 'pair = ? AND timeframe = ?', whereArgs: [pair, timeframe]);
  }
}
