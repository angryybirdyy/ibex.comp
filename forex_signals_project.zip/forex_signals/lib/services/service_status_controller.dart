import 'package:flutter/foundation.dart';

import '../core/enums.dart';

/// Holds the small `LIVE / MONITORING / PAUSED / OFFLINE / ERROR` indicator
/// state (spec section 3) for the UI to display.
///
/// The background monitoring cycle runs in a **separate isolate**
/// (`flutter_foreground_task` requirement — see `services/background_service.dart`),
/// so it cannot hold a reference to this object directly. Instead:
///  - The background isolate calls `FlutterForegroundTask.sendDataToMain(...)`
///    after every cycle.
///  - `app.dart` registers `FlutterForegroundTask.addTaskDataCallback` once
///    at startup and forwards whatever arrives into this controller via
///    [applyUpdate].
///  - If the app was closed and reopened, [ServiceStatusController] falls
///    back to whatever is in `sync_state` (read once at startup) until the
///    next live push arrives — see `screens/root_shell.dart`.
class ServiceStatusController extends ChangeNotifier {
  ServiceStatus _status = ServiceStatus.paused;
  DateTime? _lastUpdateUtc;
  String? _lastErrorMessage;

  ServiceStatus get status => _status;
  DateTime? get lastUpdateUtc => _lastUpdateUtc;
  String? get lastErrorMessage => _lastErrorMessage;

  void applyUpdate({
    required ServiceStatus status,
    DateTime? lastUpdateUtc,
    String? errorMessage,
  }) {
    _status = status;
    if (lastUpdateUtc != null) _lastUpdateUtc = lastUpdateUtc;
    _lastErrorMessage = errorMessage;
    notifyListeners();
  }

  /// Parses the `Map<String, dynamic>` shape sent over
  /// `FlutterForegroundTask.sendDataToMain` — kept as a named constructor
  /// input rather than assuming callers hand-build the map correctly.
  void applyFromMessage(Object? message) {
    if (message is! Map) return;
    final statusName = message['status'] as String?;
    final status = ServiceStatus.values.firstWhere(
      (s) => s.name == statusName,
      orElse: () => _status,
    );
    final tsRaw = message['lastUpdateUtc'] as String?;
    applyUpdate(
      status: status,
      lastUpdateUtc: tsRaw == null ? null : DateTime.tryParse(tsRaw),
      errorMessage: message['error'] as String?,
    );
  }
}
