import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../core/id_utils.dart';
import '../core/logger.dart';
import '../models/signal.dart';

/// Owns the app's one notification channel and turns a newly created
/// [Signal] into the notification content described in spec section 28.
///
/// Deliberately **not** wired into [SignalEngine] directly — the engine
/// only reports which signals are new; whoever drives a cycle (the
/// foreground UI's provider, or `services/background_service.dart`'s
/// TaskHandler) decides whether to call this, which keeps the engine
/// testable with plain `flutter test` (no platform channel needed) and
/// this class swappable without touching signal logic.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  static const String channelId = 'forex_signals_channel';
  static const String channelName = 'Trading Signals';
  static const String channelDescription = 'New BUY/SELL signals from your enabled strategies';

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);

    const channel = AndroidNotificationChannel(
      channelId,
      channelName,
      description: channelDescription,
      importance: Importance.high,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    _initialized = true;
  }

  /// Requests the runtime POST_NOTIFICATIONS permission (Android 13+). A
  /// no-op, returning `true`, on older Android versions where the
  /// permission doesn't exist.
  Future<bool> requestPermission() async {
    final granted = await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
    return granted ?? true;
  }

  /// Stable per-signal notification id, derived from the signal's own
  /// deterministic id — a second call for the same signal replaces the
  /// existing notification instead of stacking a duplicate (spec section
  /// 28: "do not send duplicate notifications for the same signal").
  int _notificationIdFor(String signalId) => int.parse(fnv1a(signalId), radix: 16) & 0x7FFFFFFF;

  Future<void> showSignalNotification(Signal signal) async {
    if (!_initialized) await initialize();
    final directionLabel = signal.direction.name.toUpperCase();
    final title = '${signal.pairCode} $directionLabel signal';
    final winRateText =
        signal.historicalWinRate == null ? 'n/a' : '${signal.historicalWinRate!.toStringAsFixed(1)}%';
    final body = '${signal.timeframeLabel} • ${signal.strategyId} • '
        'Entry ${signal.entryPrice.toStringAsFixed(5)} • Win rate $winRateText';

    const androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDescription,
      importance: Importance.high,
      priority: Priority.high,
      category: AndroidNotificationCategory.status,
    );

    try {
      await _plugin.show(
        _notificationIdFor(signal.id),
        title,
        body,
        const NotificationDetails(android: androidDetails),
      );
    } catch (e) {
      // Notifications are a courtesy, not core functionality — a failure
      // here must never take down a signal cycle (spec section 18/35).
      AppLogger.instance.error('NotificationService', 'Failed to show notification', e);
    }
  }
}
