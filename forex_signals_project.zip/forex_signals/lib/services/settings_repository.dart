import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_settings.dart';

/// Persists [AppSettings] (everything except the API key, which lives in
/// [ApiKeyStore] instead) via SharedPreferences. Read by both the
/// foreground UI and the background isolate — SharedPreferences is safe to
/// open independently from multiple isolates since it's just a thin,
/// plugin-mediated wrapper over a single underlying file.
class SettingsRepository {
  SettingsRepository._();
  static final SettingsRepository instance = SettingsRepository._();

  static const _prefix = 'settings_';

  Future<AppSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    final map = <String, Object?>{
      'dataMode': prefs.getString('${_prefix}dataMode'),
      'refreshIntervalMinutes': prefs.getInt('${_prefix}refreshIntervalMinutes'),
      'backgroundMonitoringEnabled': prefs.getBool('${_prefix}backgroundMonitoringEnabled'),
      'notificationsEnabled': prefs.getBool('${_prefix}notificationsEnabled'),
      'darkMode': prefs.getBool('${_prefix}darkMode'),
      'defaultTimeframeLabel': prefs.getString('${_prefix}defaultTimeframeLabel'),
      'backtestMonths': prefs.getInt('${_prefix}backtestMonths'),
      'tpSlMethod': prefs.getString('${_prefix}tpSlMethod'),
      'atrMultiple': prefs.getDouble('${_prefix}atrMultiple'),
      'fixedPips': prefs.getDouble('${_prefix}fixedPips'),
      'evaluationWindowCandles': prefs.getInt('${_prefix}evaluationWindowCandles'),
      'hasCompletedFirstRun': prefs.getBool('${_prefix}hasCompletedFirstRun'),
      'backgroundTimeframeLabels': prefs.getString('${_prefix}backgroundTimeframeLabels'),
    };
    return AppSettings.fromMap(map);
  }

  Future<void> save(AppSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    final map = settings.toMap();
    for (final entry in map.entries) {
      final key = '$_prefix${entry.key}';
      final value = entry.value;
      if (value is String) {
        await prefs.setString(key, value);
      } else if (value is bool) {
        await prefs.setBool(key, value);
      } else if (value is int) {
        await prefs.setInt(key, value);
      } else if (value is double) {
        await prefs.setDouble(key, value);
      }
    }
  }
}
