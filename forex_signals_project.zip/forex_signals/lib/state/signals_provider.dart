import 'package:flutter/foundation.dart';

import '../core/enums.dart';
import '../core/market_types.dart';
import '../models/signal.dart';
import '../services/notification_service.dart';
import 'app_services.dart';

/// Filter state for the History page (spec section 15: sortable/filterable
/// by pair, strategy, direction, timeframe, win/loss, date).
class SignalHistoryFilter {
  CurrencyPair? pair;
  String? strategyId;
  SignalDirection? direction;
  Timeframe? timeframe;
  SignalResultType? resultType;

  bool get isEmpty =>
      pair == null && strategyId == null && direction == null && timeframe == null && resultType == null;

  void clear() {
    pair = null;
    strategyId = null;
    direction = null;
    timeframe = null;
    resultType = null;
  }
}

/// Backs both pages of the Signals tab (spec sections 10/11/15). Current
/// and History are two independently loaded lists rather than one list
/// sliced client-side, so History's filters never have to fight with
/// Current's own (unfiltered, always-everything) view.
class SignalsProvider extends ChangeNotifier {
  SignalsProvider(this._appServices);
  final AppServices _appServices;

  List<Signal> current = [];
  List<Signal> history = [];
  final SignalHistoryFilter historyFilter = SignalHistoryFilter();
  bool isLoading = false;
  bool isRunningManualCycle = false;

  Future<void> loadCurrent() async {
    current = await _appServices.signalDao.getActive();
    notifyListeners();
  }

  Future<void> loadHistory() async {
    final rows = await _appServices.signalDao.query(
      pair: historyFilter.pair?.code,
      timeframe: historyFilter.timeframe?.label,
      strategyId: historyFilter.strategyId,
      direction: historyFilter.direction,
      resultType: historyFilter.resultType,
      orderBy: 'created_at DESC',
      limit: 500,
    );
    // "History" means resolved or expired — Current already owns `active`.
    history = rows.where((s) => s.status != SignalStatus.active).toList();
    notifyListeners();
  }

  Future<void> applyHistoryFilterAndReload() => loadHistory();

  Future<void> loadAll() async {
    isLoading = true;
    notifyListeners();
    await Future.wait([loadCurrent(), loadHistory()]);
    isLoading = false;
    notifyListeners();
  }

  /// Pull-to-refresh: runs a real signal-engine cycle for every pair across
  /// the timeframes the user has data for, then reloads both lists. This is
  /// the same [SignalEngine] the background service uses — a manual refresh
  /// and a background tick produce identical, comparable results.
  Future<void> runManualRefresh({required List<Timeframe> timeframes, bool notify = true}) async {
    isRunningManualCycle = true;
    notifyListeners();
    for (final pair in CurrencyPair.values) {
      for (final tf in timeframes) {
        final summary = await _appServices.signalEngine.runCycle(pair, tf);
        if (notify && _appServices.settings.notificationsEnabled) {
          for (final signal in summary.newlyCreated) {
            await NotificationService.instance.showSignalNotification(signal);
          }
        }
      }
    }
    isRunningManualCycle = false;
    await loadAll();
  }
}
