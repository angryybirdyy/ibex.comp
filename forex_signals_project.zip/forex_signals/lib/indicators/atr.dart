import '../models/candle.dart';
import 'indicator_utils.dart';

/// Wilder's ATR: Wilder-smoothed average of the True Range series. Used
/// directly by the ATR Breakout strategy and, more broadly, by the
/// TP/SL engine (`backtesting/tpsl_rules.dart`) to size targets relative to
/// each pair's current volatility instead of a fixed pip count.
class Atr {
  static List<double?> compute(CandleSeries series, {int period = 14}) {
    final tr = trueRangeSeries(series.highs, series.lows, series.closes);
    // trueRangeSeries has a leading null (index 0); Wilder smoothing needs a
    // plain double list, so we smooth from index 1 onward and re-offset.
    if (tr.length < 2) return List<double?>.filled(tr.length, null);
    final trTail = tr.sublist(1).cast<double>();
    final smoothedTail = wilderSmoothSeries(trTail, period);
    final out = List<double?>.filled(tr.length, null);
    for (int i = 0; i < smoothedTail.length; i++) {
      out[i + 1] = smoothedTail[i];
    }
    return out;
  }
}
