import '../models/candle.dart';

/// Caches indicator output keyed by (pair, timeframe, candle count, last
/// candle timestamp, indicator+params signature). Because the key embeds
/// how many candles and what the newest candle's timestamp is, a cache hit
/// is only possible when the underlying series truly hasn't changed since
/// last time — there's no possibility of silently serving stale values
/// after a new candle arrives (spec section 21: "cache calculated
/// indicators where appropriate").
///
/// Bounded to [_maxEntries] using simple insertion-order eviction so a
/// long-running background service can't grow this unboundedly (spec
/// section 47: "avoid memory leaks").
class IndicatorEngine {
  IndicatorEngine._();

  static const int _maxEntries = 500;
  static final Map<String, Object?> _cache = <String, Object?>{};

  static String seriesKey(CandleSeries series, String pairCode, String timeframeLabel) {
    final tail = series.isEmpty ? 'empty' : series.last.timestamp.toIso8601String();
    return '$pairCode|$timeframeLabel|${series.length}|$tail';
  }

  /// Returns the cached value for [key] if present, otherwise computes it
  /// with [compute], stores it, and returns it.
  static T memoize<T>(String key, T Function() compute) {
    if (_cache.containsKey(key)) {
      return _cache[key] as T;
    }
    final value = compute();
    if (_cache.length >= _maxEntries) {
      _cache.remove(_cache.keys.first);
    }
    _cache[key] = value;
    return value;
  }

  static void clear() => _cache.clear();
}
