import '../models/candle.dart';
import 'indicator_utils.dart';

class MacdResult {
  const MacdResult(this.macdLine, this.signalLine, this.histogram);
  final List<double?> macdLine;
  final List<double?> signalLine;
  final List<double?> histogram;
}

/// Standard MACD: `EMA(fast) - EMA(slow)`, signal = `EMA(signalPeriod)` of
/// the MACD line, histogram = `macd - signal`.
class Macd {
  static MacdResult compute(
    CandleSeries series, {
    int fast = 12,
    int slow = 26,
    int signalPeriod = 9,
  }) {
    final closes = series.closes;
    final emaFast = emaSeries(closes, fast);
    final emaSlow = emaSeries(closes, slow);
    final macdLine = List<double?>.filled(closes.length, null);
    for (int i = 0; i < closes.length; i++) {
      final f = emaFast[i], s = emaSlow[i];
      if (f != null && s != null) macdLine[i] = f - s;
    }

    // EMA of the MACD line, but only over the defined (non-null) tail.
    final firstDefined = macdLine.indexWhere((v) => v != null);
    final signalLine = List<double?>.filled(closes.length, null);
    if (firstDefined != -1 && closes.length - firstDefined >= signalPeriod) {
      final tail = macdLine.sublist(firstDefined).cast<double>();
      final tailEma = emaSeries(tail, signalPeriod);
      for (int i = 0; i < tailEma.length; i++) {
        signalLine[firstDefined + i] = tailEma[i];
      }
    }

    final histogram = List<double?>.filled(closes.length, null);
    for (int i = 0; i < closes.length; i++) {
      final m = macdLine[i], s = signalLine[i];
      if (m != null && s != null) histogram[i] = m - s;
    }

    return MacdResult(macdLine, signalLine, histogram);
  }
}
