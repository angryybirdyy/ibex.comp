import '../models/candle.dart';
import 'indicator_utils.dart';

/// Thin, named wrappers around the generic rolling-window math in
/// `indicator_utils.dart`, so strategy code reads as `Sma.compute(...)`
/// rather than a bare `smaSeries(...)` call.
class Sma {
  static List<double?> compute(CandleSeries series, {required int period}) =>
      smaSeries(series.closes, period);
}

class Ema {
  static List<double?> compute(CandleSeries series, {required int period}) =>
      emaSeries(series.closes, period);
}
