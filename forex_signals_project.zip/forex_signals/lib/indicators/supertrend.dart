import '../models/candle.dart';
import 'atr.dart';

class SupertrendResult {
  const SupertrendResult(this.line, this.isUptrend);

  /// The Supertrend line itself (acts as a trailing stop / trend line).
  final List<double?> line;

  /// `true` while price is above the line (uptrend), `false` below, `null`
  /// during ATR warm-up. A change from false→true or true→false is the
  /// strategy's buy/sell trigger.
  final List<bool?> isUptrend;
}

/// Standard Supertrend (Olivier Seban's formulation, as implemented by
/// every major charting platform):
///  - basic bands = `(high+low)/2 ± multiplier * ATR(period)`
///  - final bands only move *toward* price, never away from it, until price
///    closes through the opposite band, which is what produces the
///    "staircase" trailing-stop look and the trend flip.
class Supertrend {
  static SupertrendResult compute(
    CandleSeries series, {
    int period = 10,
    double multiplier = 3.0,
  }) {
    final highs = series.highs, lows = series.lows, closes = series.closes;
    final n = closes.length;
    final atr = Atr.compute(series, period: period);
    final line = List<double?>.filled(n, null);
    final trendUp = List<bool?>.filled(n, null);

    final firstDefined = atr.indexWhere((v) => v != null);
    if (firstDefined == -1) return SupertrendResult(line, trendUp);

    double finalUpper = (highs[firstDefined] + lows[firstDefined]) / 2 +
        multiplier * atr[firstDefined]!;
    double finalLower = (highs[firstDefined] + lows[firstDefined]) / 2 -
        multiplier * atr[firstDefined]!;
    bool up = closes[firstDefined] > finalUpper ? true : false;
    line[firstDefined] = up ? finalLower : finalUpper;
    trendUp[firstDefined] = up;

    for (int i = firstDefined + 1; i < n; i++) {
      final a = atr[i];
      if (a == null) continue;
      final mid = (highs[i] + lows[i]) / 2;
      final basicUpper = mid + multiplier * a;
      final basicLower = mid - multiplier * a;

      final newFinalUpper =
          (basicUpper < finalUpper || closes[i - 1] > finalUpper) ? basicUpper : finalUpper;
      final newFinalLower =
          (basicLower > finalLower || closes[i - 1] < finalLower) ? basicLower : finalLower;

      bool newUp = up;
      if (up && closes[i] < newFinalLower) {
        newUp = false;
      } else if (!up && closes[i] > newFinalUpper) {
        newUp = true;
      }

      finalUpper = newFinalUpper;
      finalLower = newFinalLower;
      up = newUp;
      line[i] = up ? finalLower : finalUpper;
      trendUp[i] = up;
    }

    return SupertrendResult(line, trendUp);
  }
}
