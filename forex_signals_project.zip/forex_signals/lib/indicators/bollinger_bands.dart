import '../models/candle.dart';
import 'indicator_utils.dart';

class BollingerBandsResult {
  const BollingerBandsResult(this.middle, this.upper, this.lower, this.bandwidth);
  final List<double?> middle;
  final List<double?> upper;
  final List<double?> lower;

  /// `(upper - lower) / middle`, used by the Bollinger squeeze strategy to
  /// detect a volatility contraction.
  final List<double?> bandwidth;
}

/// Standard Bollinger Bands: SMA(period) middle band, ± [stdDevMultiple]
/// population standard deviations for the outer bands.
class BollingerBands {
  static BollingerBandsResult compute(
    CandleSeries series, {
    int period = 20,
    double stdDevMultiple = 2.0,
  }) {
    final closes = series.closes;
    final middle = smaSeries(closes, period);
    final std = rollingStdDev(closes, period);
    final upper = List<double?>.filled(closes.length, null);
    final lower = List<double?>.filled(closes.length, null);
    final bandwidth = List<double?>.filled(closes.length, null);
    for (int i = 0; i < closes.length; i++) {
      final m = middle[i], s = std[i];
      if (m != null && s != null) {
        upper[i] = m + stdDevMultiple * s;
        lower[i] = m - stdDevMultiple * s;
        bandwidth[i] = m == 0 ? null : (upper[i]! - lower[i]!) / m;
      }
    }
    return BollingerBandsResult(middle, upper, lower, bandwidth);
  }
}
