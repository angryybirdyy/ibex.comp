import 'dart:collection';
import 'dart:math' as math;

/// Every function here returns a `List<double?>` the same length as the
/// input, with `null` for indices where the indicator isn't yet defined
/// (the warm-up period). This lets callers zip an indicator series 1:1
/// against candles by index without separately tracking an offset.

List<double?> smaSeries(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  double sum = 0;
  for (int i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) sum -= values[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

/// Standard EMA seeded with a simple average of the first [period] values,
/// which is the conventional approach (avoids seeding bias from using the
/// very first value alone).
List<double?> emaSeries(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  final k = 2 / (period + 1);
  double seed = 0;
  for (int i = 0; i < period; i++) {
    seed += values[i];
  }
  seed /= period;
  out[period - 1] = seed;
  double prev = seed;
  for (int i = period; i < values.length; i++) {
    final v = (values[i] - prev) * k + prev;
    out[i] = v;
    prev = v;
  }
  return out;
}

/// Wilder's smoothing (used by RSI, ATR, ADX): seed = SMA of first
/// [period] values, then `prev - prev/period + value`.
List<double?> wilderSmoothSeries(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  double seed = 0;
  for (int i = 0; i < period; i++) {
    seed += values[i];
  }
  seed /= period;
  out[period - 1] = seed;
  double prev = seed;
  for (int i = period; i < values.length; i++) {
    final v = prev - (prev / period) + values[i];
    out[i] = v;
    prev = v;
  }
  return out;
}

List<double?> rollingStdDev(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  for (int i = period - 1; i < values.length; i++) {
    double mean = 0;
    for (int j = i - period + 1; j <= i; j++) {
      mean += values[j];
    }
    mean /= period;
    double variance = 0;
    for (int j = i - period + 1; j <= i; j++) {
      final d = values[j] - mean;
      variance += d * d;
    }
    variance /= period;
    out[i] = math.sqrt(variance);
  }
  return out;
}

/// O(n) rolling maximum via a monotonic decreasing deque of indices (each
/// index enters and leaves the deque at most once, so this is linear in
/// [values.length] regardless of [period] — important because this is
/// called on every step of a backtest replay; a naive O(n·period) rescan,
/// as in a first draft of this function, turns an O(n) backtest into an
/// O(n²·period) one).
List<double?> rollingHighest(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  final deque = Queue<int>(); // indices, values strictly decreasing
  for (int i = 0; i < values.length; i++) {
    while (deque.isNotEmpty && values[deque.last] <= values[i]) {
      deque.removeLast();
    }
    deque.addLast(i);
    if (deque.first <= i - period) {
      deque.removeFirst();
    }
    if (i >= period - 1) out[i] = values[deque.first];
  }
  return out;
}

/// O(n) rolling minimum — mirror of [rollingHighest] with a monotonic
/// increasing deque.
List<double?> rollingLowest(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  if (period <= 0 || values.length < period) return out;
  final deque = Queue<int>(); // indices, values strictly increasing
  for (int i = 0; i < values.length; i++) {
    while (deque.isNotEmpty && values[deque.last] >= values[i]) {
      deque.removeLast();
    }
    deque.addLast(i);
    if (deque.first <= i - period) {
      deque.removeFirst();
    }
    if (i >= period - 1) out[i] = values[deque.first];
  }
  return out;
}

/// Applies [wilderSmoothSeries] to a nullable input by skipping the leading
/// run of nulls, smoothing the defined tail, and re-offsetting the result
/// back into a full-length series. Several indicators (ADX, Supertrend)
/// build on a value that's itself only defined after some warm-up (e.g. True
/// Range starts at index 1) — this avoids re-deriving that offset math in
/// every indicator file.
List<double?> wilderSmoothNullable(List<double?> values, int period) {
  final out = List<double?>.filled(values.length, null);
  final firstDefined = values.indexWhere((v) => v != null);
  if (firstDefined == -1) return out;
  final tail = values.sublist(firstDefined).cast<double>();
  final smoothedTail = wilderSmoothSeries(tail, period);
  for (int i = 0; i < smoothedTail.length; i++) {
    out[firstDefined + i] = smoothedTail[i];
  }
  return out;
}

/// True Range series (needs previous close, so index 0 is always null).
List<double?> trueRangeSeries(List<double> highs, List<double> lows, List<double> closes) {
  final out = List<double?>.filled(highs.length, null);
  for (int i = 1; i < highs.length; i++) {
    final hl = highs[i] - lows[i];
    final hc = (highs[i] - closes[i - 1]).abs();
    final lc = (lows[i] - closes[i - 1]).abs();
    out[i] = math.max(hl, math.max(hc, lc));
  }
  return out;
}

/// Indices of local minima: `values[i]` is strictly lower than every value
/// within [leftRight] bars on both sides. Shared by the RSI Divergence and
/// Support/Resistance Breakout strategies to find recent swing points
/// without duplicating pivot-detection logic in each.
List<int> findSwingLowIndices(List<double> values, {int leftRight = 3}) {
  final out = <int>[];
  for (int i = leftRight; i < values.length - leftRight; i++) {
    bool isSwing = true;
    for (int j = i - leftRight; j <= i + leftRight; j++) {
      if (j == i) continue;
      if (values[j] <= values[i]) {
        isSwing = false;
        break;
      }
    }
    if (isSwing) out.add(i);
  }
  return out;
}

List<int> findSwingHighIndices(List<double> values, {int leftRight = 3}) {
  final out = <int>[];
  for (int i = leftRight; i < values.length - leftRight; i++) {
    bool isSwing = true;
    for (int j = i - leftRight; j <= i + leftRight; j++) {
      if (j == i) continue;
      if (values[j] >= values[i]) {
        isSwing = false;
        break;
      }
    }
    if (isSwing) out.add(i);
  }
  return out;
}

/// Rate of change over [period] bars, as a percentage.
List<double?> rocSeries(List<double> values, int period) {
  final out = List<double?>.filled(values.length, null);
  for (int i = period; i < values.length; i++) {
    final past = values[i - period];
    if (past != 0) out[i] = (values[i] - past) / past * 100.0;
  }
  return out;
}

/// Crossed [a] above [b] between index i-1 and i (both must be defined at
/// both indices). Shared by every crossover-style strategy.
bool crossedAbove(List<double?> a, List<double?> b, int i) {
  if (i <= 0) return false;
  final a0 = a[i - 1], a1 = a[i], b0 = b[i - 1], b1 = b[i];
  if (a0 == null || a1 == null || b0 == null || b1 == null) return false;
  return a0 <= b0 && a1 > b1;
}

bool crossedBelow(List<double?> a, List<double?> b, int i) {
  if (i <= 0) return false;
  final a0 = a[i - 1], a1 = a[i], b0 = b[i - 1], b1 = b[i];
  if (a0 == null || a1 == null || b0 == null || b1 == null) return false;
  return a0 >= b0 && a1 < b1;
}
