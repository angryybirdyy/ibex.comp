import 'dart:math' as math;
import '../models/candle.dart';

/// Wilder's original iterative Parabolic SAR.
///
/// Seeded from the first two bars' direction (uptrend if bar 1 closes above
/// bar 0), then each subsequent bar:
///  - SAR moves toward the extreme point (EP) by the acceleration factor
///    (AF), starting at [step] and increasing by [step] (capped at [maxAf])
///    every time a new EP is made.
///  - SAR is clamped so it never sits inside the prior two bars' range.
///  - If price crosses the SAR, the trend flips: SAR jumps to the old EP,
///    EP resets to the current extreme, and AF resets to [step].
///
/// A trend flip (detectable as `close[i]` crossing from below `sar[i-1]` to
/// above, or vice versa) is what strategies use as the buy/sell trigger.
class ParabolicSar {
  static List<double?> compute(
    CandleSeries series, {
    double step = 0.02,
    double maxAf = 0.2,
  }) {
    final highs = series.highs, lows = series.lows, closes = series.closes;
    final n = closes.length;
    final out = List<double?>.filled(n, null);
    if (n < 2) return out;

    bool up = closes[1] >= closes[0];
    double ep = up ? highs[1] : lows[1];
    double af = step;
    double sar = up ? lows[0] : highs[0];
    out[1] = sar;

    for (int i = 2; i < n; i++) {
      double candidate = sar + af * (ep - sar);

      if (up) {
        final clip = math.min(lows[i - 1], lows[i - 2]);
        if (candidate > clip) candidate = clip;
        if (lows[i] < candidate) {
          up = false;
          sar = ep;
          ep = lows[i];
          af = step;
        } else {
          sar = candidate;
          if (highs[i] > ep) {
            ep = highs[i];
            af = math.min(af + step, maxAf);
          }
        }
      } else {
        final clip = math.max(highs[i - 1], highs[i - 2]);
        if (candidate < clip) candidate = clip;
        if (highs[i] > candidate) {
          up = true;
          sar = ep;
          ep = highs[i];
          af = step;
        } else {
          sar = candidate;
          if (lows[i] < ep) {
            ep = lows[i];
            af = math.min(af + step, maxAf);
          }
        }
      }
      out[i] = sar;
    }
    return out;
  }
}
