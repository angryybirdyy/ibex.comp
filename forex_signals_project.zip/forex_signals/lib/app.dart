import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:provider/provider.dart';

import 'core/app_theme.dart';
import 'screens/first_run/first_run_screen.dart';
import 'screens/root_shell.dart';
import 'services/service_status_controller.dart';
import 'state/app_services.dart';
import 'state/settings_provider.dart';
import 'state/signals_provider.dart';
import 'state/strategy_settings_provider.dart';

class ForexSignalsRoot extends StatelessWidget {
  const ForexSignalsRoot({super.key, required this.appServices});
  final AppServices appServices;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<AppServices>.value(value: appServices),
        ChangeNotifierProvider(create: (_) => SettingsProvider(appServices)),
        ChangeNotifierProvider(create: (_) => StrategySettingsProvider(appServices.strategySettingsDao)..load()),
        ChangeNotifierProvider(create: (_) => SignalsProvider(appServices)),
        ChangeNotifierProvider(create: (_) => ServiceStatusController()),
      ],
      child: const _ForegroundTaskListener(child: _AppView()),
    );
  }
}

/// Forwards live status pushes from the background isolate into
/// [ServiceStatusController] (see that class's doc comment for why this
/// indirection exists). `WithForegroundTask` keeps the plugin's
/// communication port alive for as long as this widget is mounted.
class _ForegroundTaskListener extends StatefulWidget {
  const _ForegroundTaskListener({required this.child});
  final Widget child;

  @override
  State<_ForegroundTaskListener> createState() => _ForegroundTaskListenerState();
}

class _ForegroundTaskListenerState extends State<_ForegroundTaskListener> {
  @override
  void initState() {
    super.initState();
    FlutterForegroundTask.addTaskDataCallback(_onTaskData);
  }

  void _onTaskData(Object data) {
    if (!mounted) return;
    context.read<ServiceStatusController>().applyFromMessage(data);
  }

  @override
  void dispose() {
    FlutterForegroundTask.removeTaskDataCallback(_onTaskData);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WithForegroundTask(child: widget.child);
  }
}

class _AppView extends StatelessWidget {
  const _AppView();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>().settings;
    return MaterialApp(
      title: 'Forex Signals',
      debugShowCheckedModeBanner: false,
      themeMode: settings.darkMode ? ThemeMode.dark : ThemeMode.light,
      darkTheme: AppTheme.darkTheme,
      theme: AppTheme.lightTheme,
      home: settings.hasCompletedFirstRun ? const RootShell() : const FirstRunScreen(),
    );
  }
}
