import '../core/enums.dart';
import '../core/time_utils.dart';

/// A stored trading signal (spec sections 11/15). One row = one strategy
/// firing on one pair/timeframe/candle. `id` is the deterministic identity
/// from `core/id_utils.dart#buildSignalIdentity`, which is what makes
/// deduplication (spec section 16) a simple "does this id already exist?"
/// check instead of fuzzy matching.
class Signal {
  const Signal({
    required this.id,
    required this.pairCode,
    required this.timeframeLabel,
    required this.strategyId,
    required this.direction,
    required this.candleTimestamp,
    required this.entryPrice,
    required this.createdAt,
    this.targetPrice,
    this.stopLossPrice,
    this.historicalWinRate,
    this.historicalSampleSize,
    this.status = SignalStatus.active,
    this.resultType = SignalResultType.pending,
    this.resultTimestamp,
    this.resultPrice,
    this.explanation = '',
    this.indicatorSnapshot = const {},
    this.isDemo = false,
  });

  final String id;
  final String pairCode;
  final String timeframeLabel;
  final String strategyId;
  final SignalDirection direction;

  /// The candle this signal is anchored to — the reproducible "market
  /// coordinate" the spec asks for (timestamp + price, not screen pixels).
  final DateTime candleTimestamp;
  final double entryPrice;

  /// When the app actually created this row (may lag [candleTimestamp]
  /// slightly if data arrived late); shown as "Signal timestamp" only when
  /// it differs meaningfully from the candle time.
  final DateTime createdAt;

  final double? targetPrice;
  final double? stopLossPrice;

  /// Win rate / sample size *as computed by the most recent backtest at the
  /// time this signal was created* — frozen at creation time so historical
  /// records don't silently change if a later backtest recalculates the
  /// number (spec section 15: "Historical win rate at time of prediction").
  final double? historicalWinRate;
  final int? historicalSampleSize;

  final SignalStatus status;
  final SignalResultType resultType;
  final DateTime? resultTimestamp;
  final double? resultPrice;

  final String explanation;
  final Map<String, double> indicatorSnapshot;

  final bool isDemo;

  Duration ageAsOf(DateTime nowUtc) => nowUtc.difference(candleTimestamp);

  Signal copyWith({
    SignalStatus? status,
    SignalResultType? resultType,
    DateTime? resultTimestamp,
    double? resultPrice,
  }) {
    return Signal(
      id: id,
      pairCode: pairCode,
      timeframeLabel: timeframeLabel,
      strategyId: strategyId,
      direction: direction,
      candleTimestamp: candleTimestamp,
      entryPrice: entryPrice,
      createdAt: createdAt,
      targetPrice: targetPrice,
      stopLossPrice: stopLossPrice,
      historicalWinRate: historicalWinRate,
      historicalSampleSize: historicalSampleSize,
      status: status ?? this.status,
      resultType: resultType ?? this.resultType,
      resultTimestamp: resultTimestamp ?? this.resultTimestamp,
      resultPrice: resultPrice ?? this.resultPrice,
      explanation: explanation,
      indicatorSnapshot: indicatorSnapshot,
      isDemo: isDemo,
    );
  }

  Map<String, Object?> toMap() => {
        'id': id,
        'pair': pairCode,
        'timeframe': timeframeLabel,
        'strategy_id': strategyId,
        'direction': direction.name,
        'candle_ts': toStorageString(candleTimestamp),
        'entry_price': entryPrice,
        'created_at': toStorageString(createdAt),
        'target_price': targetPrice,
        'stop_loss_price': stopLossPrice,
        'hist_win_rate': historicalWinRate,
        'hist_sample_size': historicalSampleSize,
        'status': status.name,
        'result_type': resultType.name,
        'result_ts': resultTimestamp == null ? null : toStorageString(resultTimestamp!),
        'result_price': resultPrice,
        'explanation': explanation,
        'indicator_snapshot_json': _encodeSnapshot(indicatorSnapshot),
        'is_demo': isDemo ? 1 : 0,
      };

  static Signal fromMap(Map<String, Object?> map) => Signal(
        id: map['id'] as String,
        pairCode: map['pair'] as String,
        timeframeLabel: map['timeframe'] as String,
        strategyId: map['strategy_id'] as String,
        direction: SignalDirection.values.byName(map['direction'] as String),
        candleTimestamp: fromStorageString(map['candle_ts'] as String),
        entryPrice: (map['entry_price'] as num).toDouble(),
        createdAt: fromStorageString(map['created_at'] as String),
        targetPrice: (map['target_price'] as num?)?.toDouble(),
        stopLossPrice: (map['stop_loss_price'] as num?)?.toDouble(),
        historicalWinRate: (map['hist_win_rate'] as num?)?.toDouble(),
        historicalSampleSize: map['hist_sample_size'] as int?,
        status: SignalStatus.values.byName(map['status'] as String),
        resultType: SignalResultType.values.byName(map['result_type'] as String),
        resultTimestamp: map['result_ts'] == null
            ? null
            : fromStorageString(map['result_ts'] as String),
        resultPrice: (map['result_price'] as num?)?.toDouble(),
        explanation: map['explanation'] as String? ?? '',
        indicatorSnapshot: _decodeSnapshot(map['indicator_snapshot_json'] as String?),
        isDemo: (map['is_demo'] as int? ?? 0) == 1,
      );

  static String _encodeSnapshot(Map<String, double> m) =>
      m.entries.map((e) => '${e.key}=${e.value}').join(';');

  static Map<String, double> _decodeSnapshot(String? s) {
    if (s == null || s.isEmpty) return const {};
    final out = <String, double>{};
    for (final part in s.split(';')) {
      final kv = part.split('=');
      if (kv.length == 2) {
        final v = double.tryParse(kv[1]);
        if (v != null) out[kv[0]] = v;
      }
    }
    return out;
  }
}
