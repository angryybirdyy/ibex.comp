import '../core/enums.dart';

/// The standardized output every strategy produces (spec section 42).
/// Nothing downstream (Signal Engine, chart overlays, backtester) accepts
/// anything else — this is the single contract new strategy #25 must also
/// satisfy.
class StrategyResult {
  const StrategyResult({
    required this.strategyId,
    required this.direction,
    required this.timestamp,
    required this.entryPriceRef,
    required this.indicatorValues,
    required this.explanation,
    this.confidence,
    this.metadata = const {},
  });

  /// Matches [StrategyMeta.id] in `strategies/strategy_registry.dart`.
  final String strategyId;
  final StrategyDirection direction;

  /// Timestamp of the candle this evaluation is based on (UTC, candle-open).
  final DateTime timestamp;

  /// The close price of the evaluated candle — used as the signal's entry
  /// price reference when [direction] is buy/sell.
  final double entryPriceRef;

  /// Optional 0..1 confidence/score. Most strategies leave this null; a
  /// handful of confirmation strategies (e.g. EMA+RSI) set it based on how
  /// many sub-conditions agree.
  final double? confidence;

  /// Named indicator values at this candle (e.g. `{'rsi': 28.4}`), shown in
  /// the signal detail view and used to draw chart overlays.
  final Map<String, double> indicatorValues;

  /// Human-readable one-or-two sentence reasoning (spec section 45).
  final String explanation;

  /// Anything else a specific strategy wants to carry through to the UI
  /// (e.g. which of two confirmation conditions fired).
  final Map<String, dynamic> metadata;
}
