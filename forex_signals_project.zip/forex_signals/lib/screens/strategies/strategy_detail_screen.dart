import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/strategy_meta.dart';
import '../../strategies/strategy.dart';
import '../../state/strategy_settings_provider.dart';

/// Full information + configurable parameters for one strategy (spec
/// sections 8 & 23), reached by tapping the (i) next to a strategy on
/// `StrategiesScreen`.
class StrategyDetailScreen extends StatelessWidget {
  const StrategyDetailScreen({super.key, required this.strategy});
  final Strategy strategy;

  @override
  Widget build(BuildContext context) {
    final meta = strategy.meta;
    return Scaffold(
      appBar: AppBar(title: Text(meta.name)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(meta.shortExplanation, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          _Section(title: 'Indicators used', body: meta.indicatorsUsed.join(', ')),
          _Section(title: 'How it calculates a signal', body: meta.calculationLogic),
          _Section(title: 'Buy conditions', body: meta.buyConditions, color: Colors.green),
          _Section(title: 'Sell conditions', body: meta.sellConditions, color: Colors.red),
          _Section(title: 'Neutral conditions', body: meta.neutralConditions),
          _Section(title: 'Suitable market conditions', body: meta.suitableMarketConditions),
          _Section(title: 'Typical weaknesses', body: meta.typicalWeaknesses),
          _Section(title: 'Usual timeframes', body: meta.usualTimeframes),
          _Section(title: 'How the historical win rate is calculated', body: StrategyMeta.winRateMethodology()),
          const Divider(height: 32),
          Text('Parameters', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (strategy.paramSpecs.isEmpty)
            const Text('This strategy has no configurable parameters.')
          else
            _ParamsEditor(strategy: strategy),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.body, this.color});
  final String title;
  final String body;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.labelLarge?.copyWith(color: color, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(body),
        ],
      ),
    );
  }
}

class _ParamsEditor extends StatelessWidget {
  const _ParamsEditor({required this.strategy});
  final Strategy strategy;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<StrategySettingsProvider>();
    final current = provider.paramsFor(strategy.id);
    return Column(
      children: [
        for (final spec in strategy.paramSpecs)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(spec.label),
                    Text(spec.isInteger
                        ? current[spec.key]!.toInt().toString()
                        : current[spec.key]!.toStringAsFixed(2)),
                  ],
                ),
                Slider(
                  value: current[spec.key]!.toDouble().clamp(spec.min.toDouble(), spec.max.toDouble()),
                  min: spec.min.toDouble(),
                  max: spec.max.toDouble(),
                  divisions: ((spec.max - spec.min) / spec.step).round().clamp(1, 1000),
                  label: current[spec.key].toString(),
                  onChanged: (v) {
                    final value = spec.isInteger ? v.round() : double.parse(v.toStringAsFixed(2));
                    context.read<StrategySettingsProvider>().setParam(strategy.id, spec.key, value);
                  },
                ),
              ],
            ),
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () => context.read<StrategySettingsProvider>().resetParams(strategy.id),
            icon: const Icon(Icons.restore),
            label: const Text('Reset parameters'),
          ),
        ),
      ],
    );
  }
}
