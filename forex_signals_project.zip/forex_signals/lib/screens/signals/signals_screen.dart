import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/enums.dart';
import '../../core/market_types.dart';
import '../../strategies/strategy_registry.dart';
import '../../state/signals_provider.dart';
import '../../widgets/settings_action_button.dart';
import 'signal_detail_screen.dart';
import 'signal_list_item.dart';

/// The Signals tab (spec section 10): CURRENT is the default page, HISTORY
/// is filterable. Both pages read from [SignalsProvider], which always
/// queries every strategy's output — never just the chart-visible subset
/// (spec section 11).
class SignalsScreen extends StatefulWidget {
  const SignalsScreen({super.key});

  @override
  State<SignalsScreen> createState() => _SignalsScreenState();
}

class _SignalsScreenState extends State<SignalsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<SignalsProvider>().loadAll());
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Signals'),
          actions: const [SettingsActionButton()],
          bottom: const TabBar(tabs: [Tab(text: 'CURRENT'), Tab(text: 'HISTORY')]),
        ),
        body: const TabBarView(children: [_CurrentPage(), _HistoryPage()]),
      ),
    );
  }
}

class _CurrentPage extends StatelessWidget {
  const _CurrentPage();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SignalsProvider>();
    return RefreshIndicator(
      onRefresh: () => provider.runManualRefresh(timeframes: Timeframe.values),
      child: provider.current.isEmpty
          ? ListView(children: const [
              SizedBox(height: 120),
              Center(child: Text('No active signals yet. Pull to refresh.')),
            ])
          : ListView.builder(
              itemCount: provider.current.length,
              itemBuilder: (context, i) {
                final signal = provider.current[i];
                return SignalListItem(
                  signal: signal,
                  onTap: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => SignalDetailScreen(signal: signal))),
                );
              },
            ),
    );
  }
}

class _HistoryPage extends StatelessWidget {
  const _HistoryPage();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SignalsProvider>();
    return Column(
      children: [
        _HistoryFilterBar(provider: provider),
        Expanded(
          child: RefreshIndicator(
            onRefresh: provider.loadHistory,
            child: provider.history.isEmpty
                ? ListView(children: const [SizedBox(height: 120), Center(child: Text('No signal history yet.'))])
                : ListView.builder(
                    itemCount: provider.history.length,
                    itemBuilder: (context, i) {
                      final signal = provider.history[i];
                      return SignalListItem(
                        signal: signal,
                        onTap: () => Navigator.of(context)
                            .push(MaterialPageRoute(builder: (_) => SignalDetailScreen(signal: signal))),
                      );
                    },
                  ),
          ),
        ),
      ],
    );
  }
}

class _HistoryFilterBar extends StatelessWidget {
  const _HistoryFilterBar({required this.provider});
  final SignalsProvider provider;

  @override
  Widget build(BuildContext context) {
    final filter = provider.historyFilter;
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
      child: Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          DropdownMenu<CurrencyPair?>(
            label: const Text('Pair'),
            initialSelection: filter.pair,
            dropdownMenuEntries: [
              const DropdownMenuEntry(value: null, label: 'All'),
              ...CurrencyPair.values.map((p) => DropdownMenuEntry(value: p, label: p.displaySymbol)),
            ],
            onSelected: (v) {
              filter.pair = v;
              provider.applyHistoryFilterAndReload();
            },
          ),
          DropdownMenu<Timeframe?>(
            label: const Text('Timeframe'),
            initialSelection: filter.timeframe,
            dropdownMenuEntries: [
              const DropdownMenuEntry(value: null, label: 'All'),
              ...Timeframe.values.map((t) => DropdownMenuEntry(value: t, label: t.label)),
            ],
            onSelected: (v) {
              filter.timeframe = v;
              provider.applyHistoryFilterAndReload();
            },
          ),
          DropdownMenu<SignalDirection?>(
            label: const Text('Direction'),
            initialSelection: filter.direction,
            dropdownMenuEntries: [
              const DropdownMenuEntry(value: null, label: 'All'),
              const DropdownMenuEntry(value: SignalDirection.buy, label: 'BUY'),
              const DropdownMenuEntry(value: SignalDirection.sell, label: 'SELL'),
            ],
            onSelected: (v) {
              filter.direction = v;
              provider.applyHistoryFilterAndReload();
            },
          ),
          DropdownMenu<SignalResultType?>(
            label: const Text('Result'),
            initialSelection: filter.resultType,
            dropdownMenuEntries: [
              const DropdownMenuEntry(value: null, label: 'All'),
              const DropdownMenuEntry(value: SignalResultType.win, label: 'WIN'),
              const DropdownMenuEntry(value: SignalResultType.loss, label: 'LOSS'),
              const DropdownMenuEntry(value: SignalResultType.unresolved, label: 'EXPIRED'),
            ],
            onSelected: (v) {
              filter.resultType = v;
              provider.applyHistoryFilterAndReload();
            },
          ),
          DropdownMenu<String?>(
            label: const Text('Strategy'),
            initialSelection: filter.strategyId,
            dropdownMenuEntries: [
              const DropdownMenuEntry(value: null, label: 'All'),
              ...StrategyRegistry.all.map((s) => DropdownMenuEntry(value: s.id, label: s.meta.name)),
            ],
            onSelected: (v) {
              filter.strategyId = v;
              provider.applyHistoryFilterAndReload();
            },
          ),
          if (!filter.isEmpty)
            TextButton.icon(
              onPressed: () {
                filter.clear();
                provider.applyHistoryFilterAndReload();
              },
              icon: const Icon(Icons.clear),
              label: const Text('Clear'),
            ),
        ],
      ),
    );
  }
}
