import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../charts/candlestick_chart.dart';
import '../../core/app_theme.dart';
import '../../core/market_types.dart';
import '../../core/time_utils.dart';
import '../../strategies/strategy_overlays.dart';
import '../../strategies/strategy_registry.dart';
import '../../state/app_services.dart';
import '../../state/chart_data_provider.dart';
import '../../state/settings_provider.dart';
import '../../state/strategy_settings_provider.dart';
import '../../widgets/service_status_chip.dart';
import '../../widgets/settings_action_button.dart';

/// One chart tab (spec sections 5/6). Used for both USD/JPY and EUR/USD —
/// the pair is the only thing that differs, so this single screen (plus the
/// shared `CandlestickChart` widget) avoids duplicating the chart code per
/// pair as spec section 6 asks.
class ChartScreen extends StatelessWidget {
  const ChartScreen({super.key, required this.pair});
  final CurrencyPair pair;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ChartDataProvider>(
      create: (ctx) {
        final settings = ctx.read<SettingsProvider>().settings;
        final tf = Timeframe.values
            .firstWhere((t) => t.label == settings.defaultTimeframeLabel, orElse: () => Timeframe.m15);
        final provider = ChartDataProvider(appServices: ctx.read<AppServices>(), pair: pair, initialTimeframe: tf);
        provider.loadInitial();
        return provider;
      },
      child: _ChartScreenBody(pair: pair),
    );
  }
}

class _ChartScreenBody extends StatelessWidget {
  const _ChartScreenBody({required this.pair});
  final CurrencyPair pair;

  @override
  Widget build(BuildContext context) {
    final chart = context.watch<ChartDataProvider>();
    final strategySettings = context.watch<StrategySettingsProvider>();

    final overlayLines = <ChartOverlaySeries>[];
    final overlayBands = <ChartBandOverlay>[];
    final badges = <ChartBadge>[];

    if (chart.series.isNotEmpty && strategySettings.isLoaded) {
      var colorIndex = 0;
      for (final strategy in StrategyRegistry.all) {
        if (!strategySettings.isChartEnabled(strategy.id)) continue;
        final color = AppColors.overlaySeries[colorIndex % AppColors.overlaySeries.length];
        colorIndex++;
        final viz = buildOverlaysFor(strategy.id, chart.series, strategySettings.paramsFor(strategy.id), pair, color);
        overlayLines.addAll(viz.lines);
        overlayBands.addAll(viz.bands);
        badges.addAll(viz.badges);
      }
    }

    final markers = <ChartMarker>[];
    if (chart.series.isNotEmpty) {
      final indexByTimestamp = <DateTime, int>{
        for (int i = 0; i < chart.series.length; i++) chart.series[i].timestamp: i,
      };
      for (final signal in chart.markerSignals) {
        final idx = indexByTimestamp[signal.candleTimestamp];
        if (idx != null) {
          markers.add(ChartMarker(candleIndex: idx, direction: signal.direction, price: signal.entryPrice));
        }
      }
    }

    final currentPrice = chart.series.isEmpty ? null : chart.series.last.close;

    return Scaffold(
      appBar: AppBar(
        title: Text(pair.displaySymbol),
        actions: const [ServiceStatusChip(), SizedBox(width: 8), SettingsActionButton()],
      ),
      body: RefreshIndicator(
        onRefresh: chart.refresh,
        child: Column(
          children: [
            _Header(pair: pair, chart: chart, currentPrice: currentPrice),
            _TimeframeSelector(chart: chart),
            if (chart.series.isNotEmpty && chart.series.last.isDemo) const _DemoBanner(),
            if (badges.isNotEmpty) _BadgeRow(badges: badges),
            Expanded(
              child: chart.series.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : CandlestickChart(
                      series: chart.series,
                      pair: pair,
                      timeframe: chart.selectedTimeframe,
                      overlays: overlayLines,
                      bandOverlays: overlayBands,
                      markers: markers,
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.pair, required this.chart, required this.currentPrice});
  final CurrencyPair pair;
  final ChartDataProvider chart;
  final double? currentPrice;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            currentPrice == null ? '—' : pair.formatPrice(currentPrice!),
            style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  chart.isOffline ? 'OFFLINE' : (chart.lastError != null ? chart.lastError!.friendlyMessage : 'Connected'),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: chart.isOffline || chart.lastError != null ? AppColors.warning : AppColors.bullish,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  chart.lastUpdatedUtc == null ? 'Never updated' : 'Updated ${formatLocal(chart.lastUpdatedUtc!)}',
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
          if (chart.isLoading) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
        ],
      ),
    );
  }
}

class _TimeframeSelector extends StatelessWidget {
  const _TimeframeSelector({required this.chart});
  final ChartDataProvider chart;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: Timeframe.values.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (context, i) {
          final tf = Timeframe.values[i];
          final selected = tf == chart.selectedTimeframe;
          return ChoiceChip(
            label: Text(tf.label),
            selected: selected,
            onSelected: (_) => chart.changeTimeframe(tf),
          );
        },
      ),
    );
  }
}

class _BadgeRow extends StatelessWidget {
  const _BadgeRow({required this.badges});
  final List<ChartBadge> badges;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      child: Wrap(
        spacing: 6,
        runSpacing: 4,
        children: badges
            .map((b) => Chip(
                  visualDensity: VisualDensity.compact,
                  label: Text('${b.label} ${b.value}', style: TextStyle(color: b.color, fontSize: 11)),
                ))
            .toList(),
      ),
    );
  }
}

class _DemoBanner extends StatelessWidget {
  const _DemoBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: AppColors.warning.withValues(alpha: 0.15),
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: const Text(
        'DEMO DATA — not live market prices',
        textAlign: TextAlign.center,
        style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700, fontSize: 11),
      ),
    );
  }
}
