import 'package:flutter/material.dart';

import '../core/market_types.dart';
import 'chart/chart_screen.dart';
import 'signals/signals_screen.dart';
import 'strategies/strategies_screen.dart';

/// The app's primary navigation (spec section 4): exactly four bottom tabs
/// — USD/JPY, EUR/USD, Signals, Strategies — each preserving its own state
/// when switching. `IndexedStack` (rather than swapping widgets in and out
/// of the tree, or a `PageView` that disposes off-screen pages) is what
/// makes state preservation automatic: every tab's widget subtree — and
/// therefore every `ChangeNotifierProvider` a tab creates for itself, like
/// `ChartDataProvider` — stays alive and simply stops being painted while
/// another tab is showing.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  static const _tabs = [
    ChartScreen(pair: CurrencyPair.usdJpy),
    ChartScreen(pair: CurrencyPair.eurUsd),
    SignalsScreen(),
    StrategiesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _tabs),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.candlestick_chart_outlined), label: 'USD/JPY'),
          BottomNavigationBarItem(icon: Icon(Icons.candlestick_chart_outlined), label: 'EUR/USD'),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_active_outlined), label: 'Signals'),
          BottomNavigationBarItem(icon: Icon(Icons.tune_outlined), label: 'Strategies'),
        ],
      ),
    );
  }
}
