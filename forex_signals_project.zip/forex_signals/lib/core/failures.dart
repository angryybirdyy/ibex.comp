/// Typed failures for the data layer (spec section 18/35): the app must
/// never crash just because a request failed, and the user should see a
/// friendly message rather than a stack trace. Every provider/repository
/// method that can fail returns `Future<Result<T>>` instead of throwing, so
/// callers are forced (via the exhaustive `switch`) to handle failure.
library;

sealed class AppFailure {
  const AppFailure(this.friendlyMessage);

  /// Short, user-facing text with no stack traces or raw exception text
  /// (spec section 35's examples, e.g. "No internet connection").
  final String friendlyMessage;
}

final class NoConnectionFailure extends AppFailure {
  const NoConnectionFailure() : super('No internet connection');
}

final class RateLimitedFailure extends AppFailure {
  const RateLimitedFailure(this.retryAfter)
      : super('API rate limit reached');
  final Duration? retryAfter;
}

final class InvalidResponseFailure extends AppFailure {
  const InvalidResponseFailure([String detail = ''])
      : _detail = detail,
        super('Market data temporarily unavailable');
  final String _detail;
  String get debugDetail => _detail;
}

final class InvalidApiKeyFailure extends AppFailure {
  const InvalidApiKeyFailure() : super('API key was rejected — check it in Settings');
}

final class MissingApiKeyFailure extends AppFailure {
  const MissingApiKeyFailure()
      : super('No API key configured — switch to Demo mode or add a key in Settings');
}

final class HistoricalDataUnavailableFailure extends AppFailure {
  const HistoricalDataUnavailableFailure() : super('Historical data unavailable');
}

final class InsufficientDataFailure extends AppFailure {
  const InsufficientDataFailure(int needed, int have)
      : super('Insufficient candles to calculate strategy (need $needed, have $have)');
}

final class TimeoutFailure extends AppFailure {
  const TimeoutFailure() : super('Market data request timed out');
}

final class UnknownFailure extends AppFailure {
  const UnknownFailure(this.debugDetail) : super('Something went wrong');
  final String debugDetail;
}

/// A minimal Result type. We deliberately don't pull in a package for this
/// — it's ~20 lines and keeping it local avoids a dependency whose API we'd
/// otherwise have to wrap anyway.
sealed class Result<T> {
  const Result();
  const factory Result.ok(T value) = Ok<T>;
  const factory Result.err(AppFailure failure) = Err<T>;

  bool get isOk => this is Ok<T>;

  R when<R>({
    required R Function(T value) ok,
    required R Function(AppFailure failure) err,
  }) {
    final self = this;
    if (self is Ok<T>) return ok(self.value);
    return err((self as Err<T>).failure);
  }
}

final class Ok<T> extends Result<T> {
  const Ok(this.value);
  final T value;
}

final class Err<T> extends Result<T> {
  const Err(this.failure);
  final AppFailure failure;
}
