import 'dart:convert';
import 'dart:typed_data';

/// A small, dependency-free FNV-1a hash. We don't need cryptographic
/// strength here — only a stable, collision-resistant *identity* string for
/// (pair, timeframe, strategy, candle, direction) tuples so the same
/// logical event always produces the same signal id (see
/// `signals/signal_deduplicator.dart`, spec section 16).
String fnv1a(String input) {
  const int fnvPrime = 0x01000193;
  int hash = 0x811c9dc5;
  final bytes = utf8.encode(input);
  for (final b in bytes) {
    hash ^= b;
    hash = (hash * fnvPrime) & 0xFFFFFFFF;
  }
  return hash.toRadixString(16).padLeft(8, '0');
}

/// Builds the canonical dedup/identity key for a signal *event*. Two calls
/// with the same logical event always produce the same string, regardless
/// of when they run — that stability is what lets
/// [SignalDeduplicator] recognise "this is the same signal we already
/// recorded" versus "this is a genuinely new event".
String buildSignalIdentity({
  required String pairCode,
  required String timeframeLabel,
  required String strategyId,
  required DateTime candleTimestampUtc,
  required String direction, // 'buy' | 'sell'
}) {
  final raw =
      '$pairCode|$timeframeLabel|$strategyId|${candleTimestampUtc.toIso8601String()}|$direction';
  return '${fnv1a(raw)}_$pairCode${timeframeLabel}_$strategyId';
}

/// Stable id for a backtest run, so re-running the same backtest
/// configuration overwrites rather than duplicates.
String buildBacktestRunId({
  required String pairCode,
  required String timeframeLabel,
  required String strategyId,
  required DateTime startUtc,
  required DateTime endUtc,
}) {
  final raw =
      '$pairCode|$timeframeLabel|$strategyId|${startUtc.toIso8601String()}|${endUtc.toIso8601String()}';
  return fnv1a(raw);
}

/// Byte-level helper used by [fnv1a]; kept here so callers needing raw
/// bytes (e.g. future exporters) don't need to re-implement UTF-8 encoding.
Uint8List utf8Bytes(String s) => Uint8List.fromList(utf8.encode(s));
