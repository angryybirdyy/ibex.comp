/// Canonical definitions of tradeable pairs and timeframes.
///
/// Both are defined so adding a new pair or timeframe later is a one-line
/// change here plus (for a pair) one new chart tab — nothing else in the
/// app hard-codes "USD/JPY" or "EUR/USD" outside of this file and the
/// bottom-navigation wiring in `screens/root_shell.dart`.
library;

/// A tradeable currency pair. Add new pairs here; every layer of the app
/// (data, indicators, strategies, signals, database) is pair-agnostic and
/// keys everything off [code].
enum CurrencyPair {
  usdJpy('USD/JPY', 'USDJPY', 3),
  eurUsd('EUR/USD', 'EURUSD', 5);

  const CurrencyPair(this.displaySymbol, this.code, this.pricePrecision);

  /// Human-readable form, e.g. "USD/JPY". Used in the UI and in the
  /// provider-facing symbol for data sources that expect "BASE/QUOTE".
  final String displaySymbol;

  /// Compact form with no separator, e.g. "USDJPY". Used as a DB key and
  /// for providers that expect a concatenated symbol.
  final String code;

  /// Decimal places conventionally quoted for this pair (JPY pairs use 3,
  /// most others use 5, matching broker "pip" convention with one extra
  /// fractional-pip digit).
  final int pricePrecision;

  /// Conventional pip size: 0.01 for JPY-quoted pairs (3-decimal quoting),
  /// 0.0001 for everything else (5-decimal quoting). Used to convert a
  /// "fixed pips" TP/SL setting into an actual price offset.
  double get pipSize => this == CurrencyPair.usdJpy ? 0.01 : 0.0001;

  static CurrencyPair fromCode(String code) =>
      CurrencyPair.values.firstWhere((p) => p.code == code, orElse: () {
        throw ArgumentError('Unknown currency pair code: $code');
      });

  String formatPrice(double price) => price.toStringAsFixed(pricePrecision);
}

/// A candle interval. [minutes] drives candle-bucket math and gap detection;
/// [apiInterval] is the Twelve Data-style interval string used by the live
/// provider. Adding a timeframe means adding one entry here — every screen
/// that lists timeframes reads from [Timeframe.values].
enum Timeframe {
  m1('1M', 1, '1min'),
  m5('5M', 5, '5min'),
  m15('15M', 15, '15min'),
  m30('30M', 30, '30min'),
  h1('1H', 60, '1h'),
  h4('4H', 240, '4h'),
  d1('1D', 1440, '1day');

  const Timeframe(this.label, this.minutes, this.apiInterval);

  /// Short label shown in the timeframe selector, e.g. "15M".
  final String label;

  /// Candle duration in minutes. Used to bucket ticks into candles and to
  /// detect missing candles in a historical series.
  final int minutes;

  /// Interval string expected by the live data provider.
  final String apiInterval;

  Duration get duration => Duration(minutes: minutes);

  static Timeframe fromLabel(String label) =>
      Timeframe.values.firstWhere((t) => t.label == label, orElse: () {
        throw ArgumentError('Unknown timeframe label: $label');
      });

  /// Timeframes that are safe to poll frequently on a free-tier data plan.
  /// Used only as the *default* background-sync selection; the user can
  /// widen or narrow this in Settings.
  static const List<Timeframe> defaultBackgroundSet = [m15, h1, h4, d1];
}
