import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/id_utils.dart';

void main() {
  group('buildSignalIdentity', () {
    final ts = DateTime.utc(2026, 9, 28, 15, 15);

    test('is stable across repeated calls with identical inputs', () {
      final a = buildSignalIdentity(
          pairCode: 'USDJPY', timeframeLabel: '15M', strategyId: 'rsi_overbought_oversold', candleTimestampUtc: ts, direction: 'buy');
      final b = buildSignalIdentity(
          pairCode: 'USDJPY', timeframeLabel: '15M', strategyId: 'rsi_overbought_oversold', candleTimestampUtc: ts, direction: 'buy');
      expect(a, b);
    });

    test('changes when any single field changes', () {
      final base = buildSignalIdentity(
          pairCode: 'USDJPY', timeframeLabel: '15M', strategyId: 'rsi_overbought_oversold', candleTimestampUtc: ts, direction: 'buy');

      expect(
          buildSignalIdentity(pairCode: 'EURUSD', timeframeLabel: '15M', strategyId: 'rsi_overbought_oversold', candleTimestampUtc: ts, direction: 'buy'),
          isNot(base));
      expect(
          buildSignalIdentity(pairCode: 'USDJPY', timeframeLabel: '1H', strategyId: 'rsi_overbought_oversold', candleTimestampUtc: ts, direction: 'buy'),
          isNot(base));
      expect(
          buildSignalIdentity(pairCode: 'USDJPY', timeframeLabel: '15M', strategyId: 'macd', candleTimestampUtc: ts, direction: 'buy'),
          isNot(base));
      expect(
          buildSignalIdentity(
              pairCode: 'USDJPY', timeframeLabel: '15M', strategyId: 'rsi_overbought_oversold', candleTimestampUtc: ts.add(const Duration(minutes: 15)), direction: 'buy'),
          isNot(base));
      expect(
          buildSignalIdentity(pairCode: 'USDJPY', timeframeLabel: '15M', strategyId: 'rsi_overbought_oversold', candleTimestampUtc: ts, direction: 'sell'),
          isNot(base));
    });
  });
}
