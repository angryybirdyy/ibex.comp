import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/indicators/indicator_utils.dart';

void main() {
  group('smaSeries', () {
    test('computes a simple average over the window', () {
      final values = [1.0, 2.0, 3.0, 4.0, 5.0];
      final sma = smaSeries(values, 3);
      expect(sma[0], isNull);
      expect(sma[1], isNull);
      expect(sma[2], closeTo(2.0, 1e-9)); // (1+2+3)/3
      expect(sma[3], closeTo(3.0, 1e-9)); // (2+3+4)/3
      expect(sma[4], closeTo(4.0, 1e-9)); // (3+4+5)/3
    });
  });

  group('emaSeries', () {
    test('seeds with a simple average then applies the EMA recurrence', () {
      final values = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0];
      final ema = emaSeries(values, 3);
      expect(ema[1], isNull);
      expect(ema[2], closeTo(2.0, 1e-9)); // seed = SMA(1,2,3)
      // k = 2/(3+1) = 0.5; ema[3] = (4-2)*0.5+2 = 3.0
      expect(ema[3], closeTo(3.0, 1e-9));
      expect(ema[4], closeTo(4.0, 1e-9));
    });
  });

  group('rollingHighest / rollingLowest (O(n) deque) matches brute force', () {
    List<double?> bruteHighest(List<double> v, int period) {
      final out = List<double?>.filled(v.length, null);
      for (int i = period - 1; i < v.length; i++) {
        double h = v[i - period + 1];
        for (int j = i - period + 2; j <= i; j++) {
          if (v[j] > h) h = v[j];
        }
        out[i] = h;
      }
      return out;
    }

    List<double?> bruteLowest(List<double> v, int period) {
      final out = List<double?>.filled(v.length, null);
      for (int i = period - 1; i < v.length; i++) {
        double l = v[i - period + 1];
        for (int j = i - period + 2; j <= i; j++) {
          if (v[j] < l) l = v[j];
        }
        out[i] = l;
      }
      return out;
    }

    test('matches on a pseudo-random series for several periods', () {
      final rnd = List.generate(200, (i) => (i * 37 % 97).toDouble() - 48.0);
      for (final period in [3, 7, 20, 50]) {
        expect(rollingHighest(rnd, period), bruteHighest(rnd, period), reason: 'period=$period');
        expect(rollingLowest(rnd, period), bruteLowest(rnd, period), reason: 'period=$period');
      }
    });
  });
}
