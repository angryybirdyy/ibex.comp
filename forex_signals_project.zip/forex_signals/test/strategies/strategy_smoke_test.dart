import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/core/market_types.dart';
import 'package:forex_signals/data/demo_data_provider.dart';
import 'package:forex_signals/models/candle.dart';
import 'package:forex_signals/strategies/strategy_registry.dart';

void main() {
  group('StrategyRegistry', () {
    test('contains exactly 24 strategies with unique ids', () {
      expect(StrategyRegistry.all.length, 24);
      final ids = StrategyRegistry.all.map((s) => s.id).toSet();
      expect(ids.length, 24, reason: 'every strategy id must be unique');
    });

    test('every strategy has at least one configurable param spec OR none, never a mismatched default', () {
      for (final strategy in StrategyRegistry.all) {
        for (final spec in strategy.paramSpecs) {
          expect(spec.defaultValue, inInclusiveRange(spec.min, spec.max),
              reason: '${strategy.id}.${spec.key} default outside its own min/max');
        }
      }
    });
  });

  group('Every strategy, run against real generated candles', () {
    late CandleSeries series;

    setUpAll(() async {
      // The demo provider is deterministic and needs no network/platform
      // channel, so this exercises every strategy's real evaluate() logic
      // (not a hand-crafted toy series) inside a plain `flutter test` run.
      final provider = DemoDataProvider();
      final result = await provider.getCandles(CurrencyPair.eurUsd, Timeframe.h1, outputSize: 400);
      series = result.when(ok: (c) => CandleSeries(c), err: (_) => CandleSeries(const []));
    });

    test('generated enough candles to be a meaningful test', () {
      expect(series.length, 400);
    });

    for (final strategy in StrategyRegistry.all) {
      test('${strategy.id}: evaluateSafe never throws and returns a valid result', () {
        final result = strategy.evaluateSafe(series);
        expect(StrategyDirection.values, contains(result.direction));
        expect(result.strategyId, strategy.id);
        expect(result.entryPriceRef, greaterThan(0));
      });

      test('${strategy.id}: returns neutral (never throws) with too little data', () {
        final tiny = CandleSeries(series.candles.take(3).toList());
        final result = strategy.evaluateSafe(tiny);
        expect(result.direction, StrategyDirection.neutral);
      });

      test('${strategy.id}: evaluating the same window twice is deterministic', () {
        final a = strategy.evaluateSafe(series);
        final b = strategy.evaluateSafe(series);
        expect(a.direction, b.direction);
        expect(a.entryPriceRef, b.entryPriceRef);
      });
    }
  });
}
