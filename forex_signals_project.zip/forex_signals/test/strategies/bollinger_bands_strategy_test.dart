import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/models/candle.dart';
import 'package:forex_signals/strategies/bollinger_bands_strategy.dart';

CandleSeries _seriesFromCloses(List<double> closes) {
  final start = DateTime.utc(2024, 1, 1);
  return CandleSeries([
    for (int i = 0; i < closes.length; i++)
      Candle(timestamp: start.add(Duration(hours: i)), open: closes[i], high: closes[i] + 0.01, low: closes[i] - 0.01, close: closes[i]),
  ]);
}

void main() {
  final strategy = BollingerBandsStrategy();

  test('fires BUY only on the re-entry candle, not while still below the band', () {
    // Stable series, then a sharp dip (pushes close below the lower band),
    // then a recovery back above it.
    final stable = List.generate(30, (_) => 100.0);
    final dip = [97.0, 96.5, 96.0];
    final recovery = [97.5, 99.5, 100.2];
    final closes = [...stable, ...dip, ...recovery];
    final series = _seriesFromCloses(closes);

    final results = <StrategyDirection>[];
    for (int i = strategy.minCandles; i < series.length; i++) {
      final window = CandleSeries(series.candles.sublist(0, i + 1));
      results.add(strategy.evaluateSafe(window, overrides: {'period': 20, 'std_dev': 2.0}).direction);
    }

    final buyCount = results.where((d) => d == StrategyDirection.buy).length;
    expect(buyCount, lessThanOrEqualTo(1), reason: 'dedup-friendly: at most one BUY for one dip/recovery event');
  });
}
