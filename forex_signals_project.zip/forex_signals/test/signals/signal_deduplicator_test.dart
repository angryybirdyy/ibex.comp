import 'package:flutter_test/flutter_test.dart';
import 'package:forex_signals/core/enums.dart';
import 'package:forex_signals/database/signal_dao.dart';
import 'package:forex_signals/models/strategy_result.dart';
import 'package:forex_signals/signals/signal_deduplicator.dart';

import '../test_utils/db_test_utils.dart';

StrategyResult _result(DateTime ts, StrategyDirection dir, {double price = 1.1000}) => StrategyResult(
      strategyId: 'rsi_overbought_oversold',
      direction: dir,
      timestamp: ts,
      entryPriceRef: price,
      indicatorValues: const {},
      explanation: 'test',
    );

void main() {
  setUpAll(initTestDatabaseFactory);

  late SignalDeduplicator dedup;
  final t0 = DateTime.utc(2024, 1, 1, 12, 0);

  setUp(() async {
    final db = await openInMemoryTestDatabase();
    dedup = SignalDeduplicator(SignalDao(db));
  });

  test('a neutral strategy result never creates a signal', () async {
    final created = await dedup.recordIfNew(
      result: _result(t0, StrategyDirection.neutral),
      pairCode: 'EURUSD',
      timeframeLabel: '15M',
    );
    expect(created, isNull);
  });

  test('the same (pair, timeframe, strategy, candle, direction) event only creates one signal', () async {
    final first = await dedup.recordIfNew(result: _result(t0, StrategyDirection.buy), pairCode: 'EURUSD', timeframeLabel: '15M');
    final second = await dedup.recordIfNew(result: _result(t0, StrategyDirection.buy), pairCode: 'EURUSD', timeframeLabel: '15M');
    expect(first, isNotNull);
    expect(second, isNull, reason: 'repeated refresh on the same candle must not duplicate');
  });

  test('a new candle timestamp creates a genuinely new signal', () async {
    final first = await dedup.recordIfNew(result: _result(t0, StrategyDirection.buy), pairCode: 'EURUSD', timeframeLabel: '15M');
    final later = t0.add(const Duration(minutes: 15));
    final second =
        await dedup.recordIfNew(result: _result(later, StrategyDirection.buy), pairCode: 'EURUSD', timeframeLabel: '15M');
    expect(first!.id, isNot(second!.id));
  });

  test('a different timeframe is an independent signal stream (spec section 17)', () async {
    final m15 = await dedup.recordIfNew(result: _result(t0, StrategyDirection.buy), pairCode: 'EURUSD', timeframeLabel: '15M');
    final h1 = await dedup.recordIfNew(result: _result(t0, StrategyDirection.buy), pairCode: 'EURUSD', timeframeLabel: '1H');
    expect(m15, isNotNull);
    expect(h1, isNotNull);
    expect(m15!.id, isNot(h1!.id));
  });

  test('a direction flip on the same candle is treated as a new event', () async {
    final buy = await dedup.recordIfNew(result: _result(t0, StrategyDirection.buy), pairCode: 'EURUSD', timeframeLabel: '15M');
    final sell = await dedup.recordIfNew(result: _result(t0, StrategyDirection.sell), pairCode: 'EURUSD', timeframeLabel: '15M');
    expect(buy, isNotNull);
    expect(sell, isNotNull);
    expect(buy!.id, isNot(sell!.id));
  });
}
