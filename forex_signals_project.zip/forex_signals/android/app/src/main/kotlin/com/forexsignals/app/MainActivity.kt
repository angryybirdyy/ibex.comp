package com.forexsignals.app

import io.flutter.embedding.android.FlutterActivity

/**
 * Standard single-Activity Flutter host. All app logic lives on the Dart
 * side; this class intentionally stays empty unless a future native
 * integration (e.g. a platform channel) needs it.
 */
class MainActivity : FlutterActivity()
