# Build

## Honesty note (read this first)

This project's source code, tests, and Android/Gradle configuration were
written in full, but in an environment with **no Flutter SDK, no Android
SDK, and no internet access** — so `flutter pub get`, `flutter analyze`,
`flutter test`, and `flutter build` could not actually be executed before
delivering this project. Nothing here is a stub, a placeholder, or
pseudocode — every file is complete, real implementation — but "I wrote
this carefully" and "I watched it compile and pass" are different claims,
and this document is upfront about which one applies.

Two things are provided specifically to close that gap honestly:

1. **`.github/workflows/build_and_test.yml`** — push this project to a
   GitHub repository and this workflow runs automatically: `flutter pub
   get` → `flutter analyze` → `flutter test` → `flutter test
   integration_test` → `flutter build apk --debug` → uploads the resulting
   APK as a downloadable build artifact. This gives you a real,
   independently-executed build and test run with no setup beyond pushing
   the code, and the Actions tab will show you exactly what passed or
   failed.
2. **`tool/verify_build.sh`** — the same sequence of commands, to run on
   your own machine once you have Flutter/Android set up locally (see
   SETUP.md). Run it with `bash tool/verify_build.sh`.

If either surfaces a failure, it's most likely one of the specific,
flagged spots listed in TROUBLESHOOTING.md under "Most likely build
issues, and why" — version drift in a fast-moving dependency between when
this was written and when you build it, not a structural problem with the
app.

## Tool versions this project targets

| Tool | Version | Why |
|---|---|---|
| Flutter | ≥ 3.44.0 | Required by `flutter_foreground_task` ^11.0.3 |
| Dart | ≥ 3.12.0 | Same |
| Android Gradle Plugin | 8.11.1 | Required by `flutter_local_notifications` ^22.3.1 |
| Gradle | 8.13 | Minimum Gradle for AGP 8.11.1 |
| Kotlin | 2.2.20 | Required by `flutter_foreground_task` ^11.0.3 |
| compileSdk / targetSdk | 36 | Current Android target at time of writing |
| minSdk | 24 (Android 7.0) | Required by `flutter_local_notifications` ^22.3.1 |

All of these are pinned in `android/settings.gradle.kts`,
`android/app/build.gradle.kts`, and `android/gradle/wrapper/gradle-wrapper.properties`.
If `flutter pub get` resolves a newer major version of one of the three
plugins named above, check its changelog for a bumped minimum and update
the matching row here — see TROUBLESHOOTING.md.

### Gradle wrapper JAR

`android/gradle/wrapper/gradle-wrapper.jar` is a compiled binary file and
is **not included** — only the real, unmodified `gradlew` / `gradlew.bat`
scripts and a correct `gradle-wrapper.properties` are. The first time you
build, either:

- Open the project in Android Studio — it detects the missing wrapper jar
  and offers to fix it automatically, or
- Run this once from the `android/` folder, using any Gradle install you
  have (Android Studio bundles one):
  ```
  cd android
  gradle wrapper --gradle-version 8.13
  cd ..
  ```

After that, `./gradlew` works standalone from then on.

## Install dependencies

```
flutter pub get
```

## Static analysis

```
flutter analyze
```

Project-specific lint config is in `analysis_options.yaml`. A handful of
`unused_import`-type lints are plausible in a project this size assembled
without a live analyzer in the loop — they're safe to clean up and don't
indicate a logic problem.

## Run the tests

```
flutter test
flutter test integration_test
```

`flutter test` covers everything under `test/` (indicators, strategies,
database, signal dedup/resolution, backtest math, widget/navigation tests).
`integration_test/` covers the full sync → signal-generation → persistence
pipeline. Both use `sqflite_common_ffi` to run against a real SQLite engine
on your machine — no emulator needed for either command.

For on-device verification of things that genuinely need a real Android
environment (the foreground service actually surviving, notification
permission prompts, battery optimization dialogs), run:
```
flutter test integration_test -d <device-id>
```
with a connected device or running emulator.

## Build a debug APK

```
flutter build apk --debug
```

Output: `build/app/outputs/flutter-apk/app-debug.apk`

## Build a release APK

```
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

**This works immediately with zero extra setup** — if you haven't created
your own signing key (below), `android/app/build.gradle.kts` falls back to
signing the release build with the same debug key as the debug build. The
APK installs and runs fine for your own personal use; the only thing you
lose by not creating a real key is the ability to publish updates to the
Play Store later under the same app identity (Google requires a consistent,
real signing key for that).

## Build an Android App Bundle (for the Play Store)

```
flutter build appbundle --release
```

Output: `build/app/outputs/bundle/release/app-release.aab`

## Creating your own signing key

Only needed if you plan to distribute this outside of just installing it
on your own phone.

```
keytool -genkey -v -keystore ~/forex-signals-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias forex_signals
```

`keytool` ships with any JDK, including the one bundled inside Android
Studio. Answer its prompts (name, organization, etc. — these go on the
certificate, not into the app). Then create `android/key.properties`
(already in `.gitignore` — never commit this file):

```
storePassword=<password you chose>
keyPassword=<password you chose>
keyAlias=forex_signals
storeFile=/absolute/path/to/forex-signals-key.jks
```

Re-run `flutter build apk --release` — it now signs with your real key
automatically (see the `signingConfigs` block in
`android/app/build.gradle.kts`, which checks for `key.properties` and
falls back to the debug key only when that file is absent).

**Back up `forex-signals-key.jks` and its passwords somewhere safe.** If
you ever lose it, you cannot publish an update to an app already
distributed under that key — Android would treat it as a different app.

## Installing the APK on your phone

1. Copy the `.apk` file to your phone (USB cable, email, cloud storage —
   any method).
2. On your phone, open the file. Android will warn about installing from
   an unknown source the first time — this is normal for any APK not from
   the Play Store; tap through to allow it for your file manager/browser.
3. Tap Install.

Or, with the phone connected via USB and USB debugging enabled:
```
adb install build/app/outputs/flutter-apk/app-release.apk
```

## Shrinking a release build (optional, not done by default)

`isMinifyEnabled` is `false` in `android/app/build.gradle.kts` for this
first build, so you get a working, unoptimized release APK with the least
chance of a reflection-related plugin breaking. Turning on R8
minification/shrinking is a reasonable follow-up once you've confirmed
everything works, but needs ProGuard keep rules verified against whichever
plugin versions `pub get` actually resolved — `android/app/proguard-rules.pro`
has a starting point.
