# Setup

## Dependencies

Everything the app needs is listed in `pubspec.yaml`. Run this once (and
again any time `pubspec.yaml` changes):

```
flutter pub get
```

This downloads packages from pub.dev — it needs internet access. Versions
are pinned with `^` (caret) constraints to known-good floor versions, so
`flutter pub get` will resolve to the newest compatible release of each —
you don't need to manually chase version numbers.

### `local.properties` (Android SDK location)

`android/local.properties` is **not** included (it's machine-specific and
listed in `.gitignore` on purpose). The very first time you open this
project, create `android/local.properties` with two lines:

```
sdk.dir=/absolute/path/to/your/Android/sdk
flutter.sdk=/absolute/path/to/your/flutter/sdk
```

If you installed Android Studio normally, it almost always creates this
file for you automatically the first time you open the `android/` folder
as a project — you usually don't need to write it by hand. If you only use
`flutter run`/`flutter build` from a terminal, Flutter's own tooling
generates it for you too.

## Project structure

```
lib/
  core/          Shared types, enums, time/id utilities, theme, logging
  models/        Plain data classes (Candle, Signal, BacktestResult, ...)
  indicators/    14 real indicator calculations (RSI, MACD, ATR, ...)
  strategies/    The 24 strategies + the registry + chart-overlay builders
  backtesting/   The backtest engine + TP/SL rules shared with live signals
  signals/       The Signal Engine, deduplication, and resolution
  database/      SQLite schema + one DAO per table
  data/          Provider abstraction (Demo + Twelve Data) + repository
  services/      Background service, notifications, secure storage, settings
  charts/        The reusable candlestick chart widget
  screens/       One folder per tab/screen
  widgets/       Small shared widgets (status chip, settings button)
  state/         ChangeNotifier-based state, one per screen/concern

test/            Unit tests, mirroring the lib/ structure
integration_test/  Multi-component tests (sync → signals → database)

android/         The native Android project (Gradle, manifest, icons)
```

See `ARCHITECTURE.md` for how these layers depend on each other and why.

## First-run checklist

1. `flutter pub get`
2. `flutter run` (Demo mode works immediately, no API key)
3. In the app: Settings → pick Demo or Live, set a refresh interval,
   decide whether to turn on background monitoring and notifications now
   or later.
4. If you want live prices: see `API_SETUP.md`.
5. If you want an installable APK: see `BUILD.md`.
